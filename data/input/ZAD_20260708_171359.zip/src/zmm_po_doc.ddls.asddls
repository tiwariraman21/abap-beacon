@AbapCatalog.sqlViewName: 'ZMM_PO_DOC_SQL'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'PO DOC'
define view ZMM_PO_DOC as select from ekko
association [ 1..*] to ekpo as POI on POI.ebeln = ekko.ebeln
{
   key ebeln,
       bstyp,
       lifnr,
       POI 
}
where bstyp ='F'
