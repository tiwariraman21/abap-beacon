class ZAIF_CL_FLIGHTBOOKING_IN definition
  public
  create public .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZAIF_CL_FLIGHTBOOKING_IN IMPLEMENTATION.
ENDCLASS.
