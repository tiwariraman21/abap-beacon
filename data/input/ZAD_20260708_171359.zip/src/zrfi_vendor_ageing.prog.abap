*&---------------------------------------------------------------------*
*& Report ZRFI_VENDOR_AGEING
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT ZRFI_VENDOR_AGEING.

TYPE-POOLS: slis. " SLIS contains all the ALV data types

INCLUDE zrfi_vendor_ageing_new_top. ""Global declaration==
INCLUDE zrfi_vendor_ageing_new_sel. ""Selection Screen declaration==
INCLUDE zrfi_vendor_ageing_new_sub. ""Subroutine declaration==
