@AbapCatalog.sqlViewName: 'ZSD_DATE_FUNC_V'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Date Func'
define view ZSD_DATE_FUNC 
as select from vbak 
    {
    key vbeln as Sales_Doc,
    
    erdat as Created_Date,
    
    // Current date
    cast( '20210901' as abap.dats) as Curr_Date,
    
    // YYYYMMDD
    //DATS_IS_VALID( cast( '20210901' as abap.dats) ) as Ret_code
    //DATS_IS_VALID( cast( '01192021' as abap.dats) ) as Ret_code
    
    // DDMMYYYY
    case DATS_IS_VALID( cast( '01092021' as abap.dats) )
        when 0 then 'Date is NOT Valid'
            when 1 then 'Date is Valid'
               else ''
    end as Ret_Text,
    
    // DATS_DAYS_BETWEEN
    DATS_DAYS_BETWEEN( 
        cast( '20210901' as abap.dats), // Order Date
        cast( '20210910' as abap.dats)  // Delivery Date
    ) as Days_Between,
    
     // DATS_ADD_DAYS  
     DATS_ADD_DAYS( 
         cast( '20210901' as abap.dats), // Order Date
         15,  // Exp. Delivery 
         'INITIAL'
         
      ) as Delivery_Date,
      
    // DATS_ADD_MONTHS
    DATS_ADD_MONTHS( 
      cast( '20210901' as abap.dats), // Order Date
      1, //Add Month
      'INITIAL'
    ) as Return_Exp
      
           
    
        
    }
    where vbtyp = 'C'
    and   netwr <> 0
    
    
    
