*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZSD_T_API_MAP001TOP.              " Global Declarations
  INCLUDE LZSD_T_API_MAP001UXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZSD_T_API_MAP001F...              " Subroutines
* INCLUDE LZSD_T_API_MAP001O...              " PBO-Modules
* INCLUDE LZSD_T_API_MAP001I...              " PAI-Modules
* INCLUDE LZSD_T_API_MAP001E...              " Events
* INCLUDE LZSD_T_API_MAP001P...              " Local class implement.
* INCLUDE LZSD_T_API_MAP001T99.              " ABAP Unit tests
  INCLUDE LZSD_T_API_MAP001F00                    . " subprograms
  INCLUDE LZSD_T_API_MAP001I00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
