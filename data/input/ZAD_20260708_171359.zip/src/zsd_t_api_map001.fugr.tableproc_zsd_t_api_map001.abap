*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZSD_T_API_MAP001
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZSD_T_API_MAP001    .

  PERFORM TABLEPROC.

ENDFUNCTION.
