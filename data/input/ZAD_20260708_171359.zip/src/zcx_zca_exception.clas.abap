class ZCX_ZCA_EXCEPTION definition
  public
  inheriting from CX_STATIC_CHECK
  create public .

public section.

  interfaces IF_T100_DYN_MSG .
  interfaces IF_T100_MESSAGE .

  methods CONSTRUCTOR
    importing
      !TEXTID like IF_T100_MESSAGE=>T100KEY optional
      !PREVIOUS like PREVIOUS optional .
  methods APPEND_MESSAGE_SY .
  methods APPEND_MESSAGE
    importing
      !IV_MSGID type SYMSGID optional
      !IV_MSGTY type SYMSGTY default CL_ESH_ADM_CONSTANTS=>GC_MSGTY_E
      !IV_MSGNO type SYMSGNO
      !IV_MSGV1 type ANY optional
      !IV_MSGV2 type ANY optional
      !IV_MSGV3 type ANY optional
      !IV_MSGV4 type ANY .
  methods PREPARE_STACK_MESSAGE
    importing
      !IT_CALLSTACK type ABAP_CALLSTACK
    returning
      value(RV_TEXT) type STRING .
  methods CLEAR .
  methods DISPLAY .
  methods DISPLAY_MESSAGE
    importing
      !IV_FIRST type ABAP_BOOL optional
      !IV_DISPLAY_LIKE type SYMSGTY optional .
protected section.
private section.

  constants GC_STACK_LEVEL type I value '2' ##NO_TEXT.
  data MS_MSG type BAPIRET2 .
  data MT_MSG type BAPIRET2_T .
  constants GC_DEFAULT_LOG type BALOBJ_D value 'LOG_ENTRY' ##NO_TEXT.
ENDCLASS.



CLASS ZCX_ZCA_EXCEPTION IMPLEMENTATION.


  METHOD append_message.
    DATA:
      lv_dummy     TYPE string,
      lv_source    TYPE string,
      lt_callstack TYPE abap_callstack.
    IF iv_msgid IS INITIAL.
      CALL FUNCTION 'SYSTEM_CALLSTACK'
        EXPORTING
          max_level = gc_stack_level
        IMPORTING
          callstack = lt_callstack.
      lv_source = prepare_stack_message( lt_callstack ).
      MESSAGE e205(ts) WITH lv_source INTO lv_dummy.
      ms_msg-id          = sy-msgid.
      ms_msg-type        = sy-msgty.
      ms_msg-number      = sy-msgno.
      ms_msg-message_v1  = sy-msgv1.
      ms_msg-message_v2  = sy-msgv2.
      ms_msg-message_v3  = sy-msgv3.
      ms_msg-message_v4  = sy-msgv4.
    ELSE.
      ms_msg-id          = iv_msgid.
      ms_msg-type        = iv_msgty.
      ms_msg-number      = iv_msgno.
      ms_msg-message_v1  = iv_msgv1.
      ms_msg-message_v2  = iv_msgv2.
      ms_msg-message_v3  = iv_msgv3.
      ms_msg-message_v4  = iv_msgv4.
    ENDIF.
    MESSAGE ID ms_msg-id TYPE ms_msg-type NUMBER ms_msg-number
      WITH ms_msg-message_v1 ms_msg-message_v2 ms_msg-message_v3 ms_msg-message_v4
      INTO ms_msg-message.
    APPEND ms_msg TO mt_msg.
  ENDMETHOD.


  method APPEND_MESSAGE_SY.

     me->append_message( iv_msgid = sy-msgid
                        iv_msgty = sy-msgty
                        iv_msgno = sy-msgno
                        iv_msgv1 = sy-msgv1
                        iv_msgv2 = sy-msgv2
                        iv_msgv3 = sy-msgv3
                        iv_msgv4 = sy-msgv4 ).
  endmethod.


  method CLEAR.
    clear :ms_msg.
    refresh : mt_msg.
  endmethod.


  method CONSTRUCTOR.
CALL METHOD SUPER->CONSTRUCTOR
EXPORTING
PREVIOUS = PREVIOUS
.
clear me->textid.
if textid is initial.
  IF_T100_MESSAGE~T100KEY = IF_T100_MESSAGE=>DEFAULT_TEXTID.
else.
  IF_T100_MESSAGE~T100KEY = TEXTID.
endif.
  endmethod.


  method DISPLAY.
  endmethod.


  METHOD display_message.
    DATA:
          ls_msg TYPE bapiret2.
    IF iv_first = abap_true.
      READ TABLE mt_msg INDEX 1 INTO ls_msg.
      IF sy-subrc = 0.
      ELSE.
        "Error handling here
      ENDIF.
    ELSE.
      ls_msg = ms_msg.
    ENDIF.
    IF ls_msg IS NOT INITIAL.
      IF iv_display_like IS INITIAL.
        MESSAGE ID ls_msg-id TYPE ls_msg-type NUMBER ls_msg-number
          WITH ls_msg-message_v1 ls_msg-message_v2 ls_msg-message_v3 ls_msg-message_v4
          DISPLAY LIKE iv_display_like.
      ENDIF.
    ENDIF.
  ENDMETHOD.


  method PREPARE_STACK_MESSAGE.
    READ TABLE it_callstack INDEX gc_stack_level ASSIGNING FIELD-SYMBOL(<lfs_callstack>).
    IF sy-subrc NE 0.
      RETURN.
    ENDIF.
    rv_text = <lfs_callstack>-mainprogram && space && <lfs_callstack>-include && space && <lfs_callstack>-blocktype.
  endmethod.
ENDCLASS.
