FUNCTION-POOL ZSD_T_API_MAP001           MESSAGE-ID SV.

* INCLUDE LZSD_T_API_MAP001D...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZSD_T_API_MAP001T00                    . "view rel. data dcl.
