*&---------------------------------------------------------------------*
*& Report ZAPI_AES128_BENE_REG
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zapi_aes128_bene_reg.

START-OF-SELECTION.

  TRY.
* Create instance with test credentials
      DATA(lo_payee_mgmt) = NEW zcl_axis_payee_mgmt(
        iv_client_id     = 'TEST-CLIENT-ID'
        iv_client_secret = 'TEST-CLIENT-SECRET'
      ).

      " Create test beneficiary data
*  DATA(ls_beneficiary) = VALUE zcl_axis_payee_mgmt=>ty_bene_insert(
*    benecode     = 'VEND01264215'
*    benename     = 'Test Beneficiary'
*    beneaccnum   = '1234567890'
*    beneifsccode = 'HDFC0000523'
*    beneactype   = '10'
*    benebankname = 'HDFC BANK'
*    beneemail    = 'test@example.com'
*    benemobile   = '9999999999'
*    benelei      = '1234567890'
*  ).
*" Register beneficiary
*  DATA(lv_success) = lo_payee_mgmt->register_beneficiary( ls_beneficiary ).
      DATA: lt_beneficiaries TYPE zcl_axis_payee_mgmt=>tt_bene_insert.

      APPEND VALUE #(
          apiversion   = '1.0'
          benecode     = 'VEND01264215'
          benename     = 'Test Vendor'
          beneaccnum   = '1234567890'
          beneifsccode = 'HDFC0000523'
          benebankname = 'HDFC Bank'
          beneaddr1    = 'Test Address'
          beneemail    = 'test@example.com'
          benemobile   = '1234567890'
        ) TO lt_beneficiaries.


      " Process registration
      IF lo_payee_mgmt->register_beneficiary( lt_beneficiaries ).
        COMMIT WORK.
        MESSAGE 'Beneficiary registration successful' TYPE 'S'.
      ELSE.
        MESSAGE 'Failed to register beneficiary' TYPE 'E'.
      ENDIF.
*  IF lv_success = abap_true.
*    MESSAGE 'Beneficiary registered successfully' TYPE 'S'.
*  ELSE.
*    MESSAGE 'Failed to register beneficiary' TYPE 'E'.
*  ENDIF.

*  CATCH cx_static_check INTO DATA(lx_error).
*      MESSAGE lx_error TYPE 'E'.
  ENDTRY.
