*  inheriting from CX_STATIC_CHECK
class ZCL_AXIS_PAYEE_MGMT definition
  public
  create public .

public section.

  types:
    BEGIN OF ty_beneficiary,
        bene_code      TYPE string,
        bene_name      TYPE string,
        bene_acc_num   TYPE string,
        bene_ifsc_code TYPE string,
        bene_email     TYPE string,
        bene_mobile    TYPE string,
        bene_lei       TYPE string,
        checksum       TYPE string,
      END OF ty_beneficiary .
  types:
    BEGIN OF ty_subheader,
        requestuuid           TYPE string,
        servicerequestid      TYPE string,
        servicerequestversion TYPE string,
        channelid             TYPE string,
      END OF ty_subheader .
  types:
    BEGIN OF ty_bene_insert,
        apiversion   TYPE string,
        benecode     TYPE string,
        benename     TYPE string,
        beneaccnum   TYPE string,
        beneifsccode TYPE string,
        beneactype   TYPE string,
        benebankname TYPE string,
        beneaddr1    TYPE string,
        beneemail    TYPE string,
        benemobile   TYPE string,
        benelei      TYPE string,
      END OF ty_bene_insert .
  types:
    tt_bene_insert TYPE STANDARD TABLE OF ty_bene_insert WITH EMPTY KEY .
  types:
    BEGIN OF ty_request_body,
        channelid  TYPE string,
        corpcode   TYPE string,
        userid     TYPE string,
        beneinsert TYPE STANDARD TABLE OF ty_bene_insert WITH EMPTY KEY,
        checksum   TYPE string,
      END OF ty_request_body .
  types:
    BEGIN OF ty_request,
        subheader      TYPE ty_subheader,
        benfregreqbody TYPE ty_request_body,
      END OF ty_request .
  types:
    BEGIN OF ty_main_request,
        beneficiaryregistrationrequest TYPE ty_request,
      END OF ty_main_request .
  types:
    " Structure for encrypted request
    BEGIN OF ty_encrypted_request_inner,
        benfregreqbodyencrypted TYPE string,
      END OF ty_encrypted_request_inner .
  types:
    BEGIN OF ty_encrypted_request,
        beneficiaryregistrationrequest TYPE ty_encrypted_request_inner,
      END OF ty_encrypted_request .

  methods CONSTRUCTOR
    importing
      !IV_CLIENT_ID type STRING
      !IV_CLIENT_SECRET type STRING .
*  BEGIN OF ty_encrypted_request_inner,
*    beneficiaryregistrationrequestbodyencrypted TYPE string,
*  END OF ty_encrypted_request_inner.
*  methods CONSTRUCTOR
*    importing
*      !TEXTID like TEXTID optional
*      !PREVIOUS like PREVIOUS optional
*    raising
*      CX_STATIC_CHECK .
  methods REGISTER_BENEFICIARY
    importing
      !IS_BENEFICIARY type TY_BENE_INSERT optional
      !IT_BENEFICIARY type TT_BENE_INSERT
    returning
      value(RV_SUCCESS) type ABAP_BOOL .
protected section.
private section.

  constants C_API_VERSION type STRING value '1.0' ##NO_TEXT.
  constants C_CHANNEL_ID type STRING value 'TXB' ##NO_TEXT.
  constants C_ENCRYPTION_KEY type STRING value '29C1EB633ECAB0CA0F52B588AE92EA31' ##NO_TEXT.
  constants C_API_ENDPOINT type STRING value 'HTTPS://SAKSHAMUAT.AXISBANK.CO.IN/GATEWAY/API/TXB/V1/PAYEE-MGMT/BENEFICIARY-REGISTRATION' ##NO_TEXT.
  data MV_CLIENT_ID type STRING .
  data MV_CLIENT_SECRET type STRING .

  methods CALCULATE_CHECKSUM
    importing
      !IS_BENEFICIARY type TY_BENEFICIARY optional
      !LS_REQUEST type TY_MAIN_REQUEST
    exporting
      !EV_HASHSTRING type XSTRING
    returning
      value(RV_CHECKSUM) type STRING .
  methods ENCRYPT_REQUEST_BODY
    importing
      !IV_DATA type XSTRING
    returning
      value(RV_ENCRYPTED) type STRING .
  methods VALIDATE_BENEFICIARY
    importing
      !IS_BENEFICIARY type TY_BENEFICIARY .
  methods XSTRING_TO_STRING
    importing
      !IV_XSTRING type XSTRING
    returning
      value(RV_STRING) type STRING .
  methods SERIALIZE_REQUEST
    importing
      !IS_DATA type ANY
    returning
      value(RV_XSTRING) type XSTRING .
ENDCLASS.



CLASS ZCL_AXIS_PAYEE_MGMT IMPLEMENTATION.


  METHOD CALCULATE_CHECKSUM.


*    TRY.
*        DATA(lo_struct_descr) = CAST cl_abap_structdescr(
*                 cl_abap_typedescr=>describe_by_data( iv_request )
*               ).
*
*        DATA(lt_components) = lo_struct_descr->get_components( ).
*        DATA(lv_checksum_string) = ||.
*
*        " Extract all values except checksum
*        LOOP AT lt_components ASSIGNING FIELD-SYMBOL(<ls_comp>).
*          IF <ls_comp>-name NE 'CHECKSUM'.
*            ASSIGN COMPONENT <ls_comp>-name OF STRUCTURE iv_request TO FIELD-SYMBOL(<fs_value>).
*            IF sy-subrc = 0 AND <fs_value> IS NOT INITIAL.
*              lv_checksum_string = |{ lv_checksum_string }{ <fs_value> }|.
*            ENDIF.
*          ENDIF.
*        ENDLOOP.
*
*        " Calculate MD5 hash
*        cl_abap_message_digest=>calculate_hash_for_char(
*         EXPORTING
*           if_algorithm = 'MD5'
*           if_data     = lv_checksum_string
*           IMPORTING
*           ef_hashxstring = ev_hashstring
*       ).
*
*        " Convert to hex string
**        rv_checksum = cl_abap_codepage=>convert_to( EV_HASHSTRING ).
*
*        " Convert hash to hex string
*        DATA: lv_hex TYPE string.
*        DO xstrlen( ev_hashstring ) TIMES.
*          DATA(lv_offset) = sy-index - 1.
*          DATA(lv_byte) = ev_hashstring+lv_offset(1).
*          lv_hex = |{ lv_hex }{ lv_byte }|.
*        ENDDO.
*
*        rv_checksum = lv_hex.
*
*      CATCH cx_root INTO DATA(lx_root).
**        RAISE EXCEPTION TYPE cx_static_check
**          EXPORTING
**            previous = lx_root.

*********************************
*****        Alternate Method

*    TRY.
*        DATA: lv_hash_string TYPE string,
*              lv_xstring     TYPE xstring.
*
*        " Prepare string for checksum
*        DATA(lv_checksum_string) = ||.
*        DATA: lO_json TYPE Xstring.
*        " Convert request to JSON string (excluding checksum)
**            DATA(lo_json) = /ui2/cl_json=>serialize(
*        lo_json = /ui2/cl_json=>serialize(
*            data = ls_request
*            pretty_name = /ui2/cl_json=>pretty_mode-low_case
*          ).
*
*        " Convert to xstring for hashing
*        lv_xstring = cl_bcs_convert=>string_to_xstring(
*          iv_string = lo_json
*          iv_codepage = '4110'  " UTF-8
*        ).
*
*        " Calculate MD5
*        CALL FUNCTION 'CALCULATE_HASH_FOR_RAW'
*          EXPORTING
*            alg            = 'MD5'
*            data           = lv_xstring
*          IMPORTING
*            hash           = rv_checksum
*          EXCEPTIONS
*            unknown_alg    = 1
*            param_error    = 2
*            internal_error = 3
*            OTHERS         = 4.
*
*        IF sy-subrc <> 0.
**          RAISE EXCEPTION TYPE cx_static_check.
*        ENDIF.
*
*      CATCH cx_root INTO DATA(lx_root).
*
*
*
*    ENDTRY.

******        Alternate Method
*    TRY.
*        DATA: lv_hash TYPE string.
*
*        " Create string from important fields
*        DATA(lv_checksum_string) = |{ Ls_request-beneficiaryregistrationrequest-benfregreqbody-channelid }| &&
*                                  |{ Ls_request-beneficiaryregistrationrequest-benfregreqbody-corpcode }| &&
*                                  |{ Ls_request-beneficiaryregistrationrequest-benfregreqbody-userid }|.
*
*        " Add beneinsert data
*        LOOP AT Ls_request-beneficiaryregistrationrequest-benfregreqbody-beneinsert
*          ASSIGNING FIELD-SYMBOL(<ls_bene>).
*          lv_checksum_string = |{ lv_checksum_string }| &&
*                              |{ <ls_bene>-benecode }| &&
*                              |{ <ls_bene>-benename }| &&
*                              |{ <ls_bene>-beneaccnum }| &&
*                              |{ <ls_bene>-beneifsccode }|.
*        ENDLOOP.
*
*        " Calculate MD5 hash
*        CALL FUNCTION 'CALCULATE_HASH_FOR_CHAR'
*          EXPORTING
*            alg                  = 'MD5'
*            data                 = lv_checksum_string
*          IMPORTING
*            hash                 = lv_hash
*          EXCEPTIONS
*            unknown_alg          = 1
*            param_error          = 2
*            internal_error       = 3
*            OTHERS              = 4.
*
*        IF sy-subrc <> 0.
**          RAISE EXCEPTION TYPE cx_static_check.
*        ENDIF.
*
*        rv_checksum = lv_hash.
*
*      CATCH cx_root INTO DATA(lx_root).
**        RAISE EXCEPTION TYPE cx_static_check
**          EXPORTING
**            previous = lx_root.
*    ENDTRY.


    TRY.
        DATA: lt_components TYPE abap_component_tab,
              lv_hash       TYPE string,
              lv_xhash      TYPE xstring.

        " Get structure components
        DATA(lo_struct) = CAST cl_abap_structdescr(
          cl_abap_typedescr=>describe_by_data( ls_request )
        ).

        lt_components = lo_struct->get_components( ).

        " Build checksum string
        DATA(lv_checksum_string) = ||.

        " Get the request body structure
        FIELD-SYMBOLS: <fs_req_body> TYPE any.
        ASSIGN COMPONENT 'BENFREGREQBODY' OF STRUCTURE
          ls_request-beneficiaryregistrationrequest TO <fs_req_body>.

        IF sy-subrc = 0.
          " Extract all values except checksum from request body
          DATA(lo_body_type) = CAST cl_abap_structdescr(
            cl_abap_typedescr=>describe_by_data( <fs_req_body> )
          ).

          DATA(lt_body_components) = lo_body_type->get_components( ).

          LOOP AT lt_body_components INTO DATA(ls_component).
            IF ls_component-name NE 'CHECKSUM'.
              ASSIGN COMPONENT ls_component-name OF STRUCTURE <fs_req_body>
                TO FIELD-SYMBOL(<fs_value>).
              IF sy-subrc = 0 AND <fs_value> IS NOT INITIAL.
                " Handle different types of fields
                CASE ls_component-type->kind.
                  WHEN cl_abap_typedescr=>kind_table.
                    " Handle table type (like beneinsert)
                    FIELD-SYMBOLS: <fs_table> TYPE ANY TABLE.
                    ASSIGN <fs_value> TO <fs_table>.
                    IF sy-subrc = 0.
                      LOOP AT <fs_table> ASSIGNING FIELD-SYMBOL(<fs_row>).
                        DATA(lo_row_type) = CAST cl_abap_structdescr(
                          cl_abap_typedescr=>describe_by_data( <fs_row> )
                        ).
                        DATA(lt_row_components) = lo_row_type->get_components( ).

                        LOOP AT lt_row_components INTO DATA(ls_row_component).
                          ASSIGN COMPONENT ls_row_component-name OF STRUCTURE <fs_row>
                            TO FIELD-SYMBOL(<fs_field>).
                          IF sy-subrc = 0 AND <fs_field> IS NOT INITIAL.
                            lv_checksum_string = |{ lv_checksum_string }{ <fs_field> }|.
                          ENDIF.
                        ENDLOOP.
                      ENDLOOP.
                    ENDIF.
                  WHEN OTHERS.
                    " Handle scalar values
                    lv_checksum_string = |{ lv_checksum_string }{ <fs_value> }|.
                ENDCASE.
              ENDIF.
            ENDIF.
          ENDLOOP.
        ENDIF.

        " Convert string to xstring for MD5 calculation
        DATA(lo_conv) = cl_abap_conv_out_ce=>create( encoding = 'UTF-8' ).
        lo_conv->convert(
          EXPORTING data = lv_checksum_string
          IMPORTING buffer = lv_xhash
        ).

        " Calculate MD5 hash
        cl_abap_message_digest=>calculate_hash_for_raw(
          EXPORTING
            if_algorithm = 'MD5'
            if_data     = lv_xhash
          IMPORTING
            ef_hashxstring = DATA(lv_md5_xstring)
        ).

***         Convert MD5 hash to hex string
        DATA(lv_hex_string) = xstring_to_string( lv_md5_xstring ).

****         Return the MD5 hash
        rv_checksum = lv_hex_string.

*    CATCH cx_root INTO DATA(lx_root).
*      RAISE EXCEPTION TYPE cx_static_check
*        EXPORTING
*          previous = lx_root.
    ENDTRY.
  ENDMETHOD.


  method CONSTRUCTOR.
*CALL METHOD SUPER->CONSTRUCTOR.
*EXPORTING
*TEXTID = TEXTID
*PREVIOUS = PREVIOUS
*.

    mv_client_id = iv_client_id.
    mv_client_secret = iv_client_secret.
  endmethod.


  METHOD encrypt_request_body.

*    TRY.
*      DATA: lv_key        TYPE xstring,
*            lv_cipher     TYPE REF TO cl_crypto_cipher,
*            lv_init_vec   TYPE xstring.
*
*      " Convert hex key to xstring - our key is already in hex format
*      lv_key = CONV xstring( c_encryption_key ).
*
*      " Prepare initialization vector (IV) as per document
*      " IV is 8E12399C076F5A8E12399C076F5A (16 bytes)
*      lv_init_vec = '8E12399C076F5A8E12399C076F5A'.
*
*      " Create cipher instance
*      TRY.
*          lv_cipher = cl_crypto_cipher=>create_symmetric(
*            EXPORTING
*              algorithm  = cl_crypto_cipher=>algorithm_aes
*              key       = lv_key
*              mode      = cl_crypto_cipher=>mode_cbc
*              padding   = cl_crypto_cipher=>padding_pkcs5
*          ).
*
*          " Encrypt the data
*          DATA(lv_encrypted) = lv_cipher->encrypt(
*            EXPORTING
*              initialization_vector = lv_init_vec
*              plaintext           = iv_data
*          ).
*
*          " Convert to Base64
*          rv_encrypted = cl_http_utility=>encode_x_base64( lv_encrypted ).
*
**        CATCH cx_crypto_cipher INTO DATA(lx_crypto).
**          RAISE EXCEPTION TYPE cx_static_check
**            EXPORTING
**              previous = lx_crypto.
*      ENDTRY.

*    CATCH cx_root INTO DATA(lx_root).
*      RAISE EXCEPTION TYPE cx_static_check
*        EXPORTING
*          previous = lx_root.
*  ENDTRY.

*    TRY.
*      CONSTANTS: lc_hex_key TYPE string VALUE '29C1EB633ECAB0CA0F52B588AE92EA31'.
*
*      DATA: lv_rc2key        TYPE sysuuid_c32,
*            lt_encrypted_tab TYPE TABLE OF x255,
*            lv_len          TYPE i,
*            lv_encrypted    TYPE xstring,
*            lt_binary       TYPE TABLE OF x255.
*
*      " Convert input xstring to binary table
*      CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
*        EXPORTING
*          buffer        = iv_data
*        IMPORTING
*          output_length = lv_len
*        TABLES
*          binary_tab    = lt_binary.
*
*      " Encrypt using GUI Crypt
*      CALL METHOD cl_gui_crypt=>encrypt_3des
*        EXPORTING
*          key     = lc_hex_key    "32-byte hex key
*          iv      = '8E12399C076F5A8E12399C076F5A'  "16-byte IV
*        IMPORTING
*          rc2key  = lv_rc2key
*        CHANGING
*          data    = lt_binary.
*
*      " Convert encrypted binary table back to xstring
*      CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
*        EXPORTING
*          input_length = lv_len
*        IMPORTING
*          buffer      = lv_encrypted
*        TABLES
*          binary_tab  = lt_binary.
*
*      " Convert to Base64
*      rv_encrypted = cl_http_utility=>encode_x_base64( lv_encrypted ).
*
*    CATCH cx_root INTO DATA(lx_root).
*      RAISE EXCEPTION TYPE cx_static_check
*        EXPORTING
*          previous = lx_root.
*  ENDTRY.

* TRY.
*      DATA: lv_env_handle    TYPE i,
*            lv_encoded       TYPE xstring,
*            lv_encrypted     TYPE xstring,
*            lt_input_data    TYPE TABLE OF x255,
*            lt_output_data   TYPE TABLE OF x255,
*            lv_len          TYPE i.
*
*      " Convert input xstring to binary table
*      CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
*        EXPORTING
*          buffer        = iv_data
*        IMPORTING
*          output_length = lv_len
*        TABLES
*          binary_tab    = lt_input_data.
*
*      " Encrypt using SSF
*      CALL FUNCTION 'SSF_KRN_ENCRYPT'
*        EXPORTING
*          algorithm    = 'AES128-CBC'  " AES-128 with CBC mode
*          key         = c_encryption_key
*          init_vector = '8E12399C07726F5A8E12399C07726F5A'
*        IMPORTING
*          encrypted   = lt_output_data
*        TABLES
*          data       = lt_input_data.
*
*      " Convert encrypted binary table back to xstring
*      CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
*        EXPORTING
*          input_length = lv_len
*        IMPORTING
*          buffer      = lv_encrypted
*        TABLES
*          binary_tab  = lt_output_data.
*
*      " Convert to Base64
*      rv_encrypted = cl_http_utility=>encode_x_base64( lv_encrypted ).
*
*    CATCH cx_root INTO DATA(lx_root).
**      RAISE EXCEPTION TYPE cx_static_check
**        EXPORTING
**          previous = lx_root.
*  ENDTRY.



******************for now
*    TRY.
*        DATA: lv_key TYPE xstring.
*        DATA lv_encrypted TYPE xstring.
*        " For debugging - check input data
*
*        WRITE: / 'Input data length:', xstrlen( iv_data ).
*
*        lv_key = CONV xstring( c_encryption_key ).
*
*        " Create encryption writer
*
*        TRY.
*
*            cl_sec_sxml_writer=>encrypt_iv(
*             EXPORTING
*               plaintext = iv_data      " Data to encrypt
*               key       = lv_key       " Encryption key
*               iv        = CONV xstring( '8E12399C07726F5A8E12399C07726F5A' ) " Init vector
*              algorithm    = 'AES128-CBC'  " AES-128 with CBC mode
*              IMPORTING
*                ciphertext = lv_encrypted
*           ).
*
*          CATCH cx_sy_no_handler INTO DATA(lx_no_handler) .
*            RAISE EXCEPTION TYPE zcx_axis_payee_mgmt
*              EXPORTING
*                textid   = zcx_axis_payee_mgmt=>encryption_failed
*                previous = lx_no_handler.
*        ENDTRY.
*        rv_encrypted = cl_http_utility=>encode_x_base64( lv_encrypted ).
*
*      CATCH cx_root INTO DATA(lx_root).
*        RAISE EXCEPTION TYPE zcx_axis_payee_mgmt
*          EXPORTING
*            textid   = zcx_axis_payee_mgmt=>encryption_failed
*            previous = lx_root.
*    ENDTRY.
*
    TRY.
      DATA: lv_key TYPE xstring,
            lv_encrypted TYPE xstring.

      " For debugging - check input data

      WRITE: / 'Input data length:', xstrlen( iv_data ).

      " Try basic encryption first
      TRY.
          " First attempt with direct call
          cl_sec_sxml_writer=>encrypt_iv(
            EXPORTING
              plaintext  = iv_data
              key       = CONV xstring( c_encryption_key )
              iv        = CONV xstring( '8E12399C07726F5A8E12399C07726F5A' )
              algorithm = 'AES128-CBC'
            IMPORTING
              ciphertext = lv_encrypted
          ).
        CATCH cx_sy_no_handler INTO DATA(lx_no_handler).
          " Log failure of first attempt
          WRITE: / 'First attempt failed:', lx_no_handler->get_text( ).

          " Second attempt - try with local variables
          DATA(lv_input) = iv_data.
          DATA(lv_iv) = CONV xstring( '8E12399C07726F5A8E12399C07726F5A' ).
          lv_key = CONV xstring( c_encryption_key ).

          cl_sec_sxml_writer=>encrypt_iv(
            EXPORTING
              plaintext  = lv_input
              key       = lv_key
              iv        = lv_iv
              algorithm = 'AES-128-CBC'  " Try alternative algorithm name
            IMPORTING
              ciphertext = lv_encrypted
          ).
      ENDTRY.

      " For debugging - check if encryption succeeded
      IF lv_encrypted IS INITIAL.
        WRITE: / 'Encryption produced no output'.
      ELSE.
        WRITE: / 'Encrypted data length:', xstrlen( lv_encrypted ).
      ENDIF.

      " Convert to Base64
      rv_encrypted = cl_http_utility=>encode_x_base64( lv_encrypted ).

    CATCH cx_root INTO DATA(lx_root).
      " Log the actual error
      WRITE: / 'Error:', lx_root->get_text( ).

      RAISE EXCEPTION TYPE zcx_axis_payee_mgmt
        EXPORTING
          textid   = zcx_axis_payee_mgmt=>encryption_failed
          previous = lx_root.
  ENDTRY.


  ENDMETHOD.


  METHOD register_beneficiary.
    " Validate beneficiary data
*    validate_beneficiary( is_beneficiary ).
    " Generate request ID
*    DATA(lv_request_uuid) = cl_system_uuid=>create_uuid_x16_static( ).
    " Prepare request payload
*     DATA : lo_json_instance TYPE REF TO CL_TREX_JSON_SERIALIZER. " Adjust the class name
*     DATA lo_json TYPE string.
*     CREATE OBJECT lo_json_instance.
*      DATA(lo_json) = cl_json_abs=>create_with_data(


*lo_json = lo_json_instance->create_with_data(
*  EXPORTING
*    data = VALUE #(
*      beneficiaryregistrationrequest = VALUE #(
*        subheader = VALUE #(
*          requestuuid = lv_request_uuid
*          servicerequestid = 'OpenAPI'
*          servicerequestversion = '1.0'
*          channelid = c_channel_id
*    )
    TRY.
        DATA(lv_uuid) = cl_system_uuid=>create_uuid_c32_static( ).
        " Prepare request body
****************        fOR NOW
*        DATA(ls_request) = VALUE ty_main_request(
*                  beneficiaryregistrationrequest = VALUE #(
*                    subheader = VALUE #(
*                       requestuuid = lv_uuid
*                       servicerequestid = 'OpenAPI'
*                       servicerequestversion = '1.0'
*                       channelid = c_channel_id
*                    )
*                     benfregreqbody  = VALUE #(
*                        channelid = c_channel_id
*                        corpcode = 'DEMOCORP11'  " Replace with actual corp code
*                        userid = sy-uname
*                     beneinsert = VALUE #( (
*                        apiversion = c_api_version
*                        benecode = is_beneficiary-benecode
*                        benename = is_beneficiary-benename
*                        beneaccnum = is_beneficiary-beneaccnum
*                        beneifsccode = is_beneficiary-beneifsccode
*                        beneactype = is_beneficiary-beneactype
*                        benebankname = is_beneficiary-benebankname
*                        beneaddr1 = is_beneficiary-beneaddr1
*                        beneemail = is_beneficiary-beneemail
*                        benemobile = is_beneficiary-benemobile
*                        benelei = is_beneficiary-benelei
*                  ) )
*                )
*              )
*            ).
*
*        " Calculate checksum
*        ls_request-beneficiaryregistrationrequest-benfregreqbody-checksum =
*          calculate_checksum( ls_request ).
****************************END FOR NOW
***************************        rEQUEST bODY
        DATA(ls_request) = VALUE ty_main_request(
              beneficiaryregistrationrequest = VALUE #(
                subheader = VALUE #(
                  requestuuid = lv_uuid
                  servicerequestid = 'OpenAPI'
                  servicerequestversion = '1.0'
                  channelid = c_channel_id
                )
                benfregreqbody = VALUE #(
                  channelid = c_channel_id
                  corpcode = 'DEMOCORP11'
                  userid = sy-uname
                  beneinsert = it_beneficiary
                )
              )
            ).

        ls_request-beneficiaryregistrationrequest-benfregreqbody-checksum =
                  calculate_checksum( ls_request ).

        " 3. Convert complete request to JSON xstring
*        DATA(lv_request_xstring) = serialize_to_json_xstring( ls_request ).
*******************************************************


*********************************************************************************
        DATA(lo_writer) = cl_sxml_string_writer=>create(
                type = if_sxml=>co_xt_json
                ignore_conversion_errors = abap_false
            ).

        " Transform data to JSON
        CALL TRANSFORMATION id
            SOURCE data = ls_request
            RESULT XML lo_writer.

        "3 Get the JSON as xstring
        DATA(lv_xjson) = lo_writer->get_output( ).

        " 4. Encrypt the entire request
        DATA(lv_encrypted_data) = encrypt_request_body( lv_xjson ).

***         5. Prepare final request with encrypted data
*        DATA(ls_final_request) = VALUE ty_encrypted_request(
*          beneficiaryregistrationrequest = VALUE #(
*            subheader = ls_request-beneficiaryregistrationrequest-subheader
*            beneficiaryregistrationrequestbodyencrypted = lv_encrypted_data
*          )
*        ).

        DATA(ls_final_request) = VALUE ty_encrypted_request(
            beneficiaryregistrationrequest-benfregreqbodyencrypted = lv_encrypted_data
).

        " Convert xstring to string
        DATA(lo_conv) = cl_abap_conv_in_ce=>create(
            input = lv_xjson
            encoding = 'UTF-8'
        ).

        DATA: lv_json TYPE xstring.
*        lo_conv->read( IMPORTING data = lv_json ).
        lo_conv->read( IMPORTING data = ls_final_request ).

        " Alternative if SXML gives empty result
        IF lv_json IS INITIAL.
          CLEAR lv_json.
          /ui2/cl_json=>serialize(
              EXPORTING
                  data             = ls_request
                  compress         = abap_false
                  pretty_name      = /ui2/cl_json=>pretty_mode-low_case
                  assoc_arrays     = abap_true
              RECEIVING
                  r_json          = lv_json
          ).
        ENDIF.

        " Verify JSON output is not empty
        IF lv_json IS INITIAL.
*          RAISE EXCEPTION TYPE cx_static_check.
        ENDIF.

*************************************************
        " Create HTTP client

        DATA: lo_http_client TYPE REF TO if_http_client.
        CALL METHOD cl_http_client=>create_by_url
          EXPORTING
            url    = 'https://sakshamuat.axisbank.co.in/gateway/api/txb/v1/payee-mgmt/beneficiary-registration'
            ssl_id = 'ANONYM'
          IMPORTING
            client = lo_http_client.

        " Set request method
        lo_http_client->request->set_method('POST').

        " Set headers
        lo_http_client->request->set_header_field(
          name  = 'Content-Type'
          value = 'application/json; charset=utf-8' "'application/json'
        ).

        lo_http_client->request->set_header_field(
                 name  = 'X-IBM-Client-Id'
                 value = mv_client_id
               ).

        lo_http_client->request->set_header_field(
              name  = 'X-IBM-Client-Secret'
              value = mv_client_secret
            ).

        " Convert xstring to binary and set as body
        DATA: lv_length TYPE i.
        DATA: lv_binary TYPE xstring.
        DATA: lt_binary TYPE TABLE OF x255.

        CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
          EXPORTING
            buffer        = lv_xjson
          IMPORTING
            output_length = lv_length
          TABLES
            binary_tab    = lt_binary.

        CONCATENATE LINES OF lt_binary INTO lv_binary IN BYTE MODE.

        " Set binary content
        lo_http_client->request->set_data( lv_binary ).
*        lo_http_client->request->set_cdata( lv_json ).

        " Send request
        lo_http_client->send(
          EXCEPTIONS
            http_communication_failure = 1
            http_invalid_state        = 2
            http_processing_failed    = 3
            http_invalid_timeout      = 4
            OTHERS                    = 5
        ).

        IF sy-subrc <> 0.
*      RAISE EXCEPTION TYPE cx_static_check.
        ENDIF.


        " Receive response
        lo_http_client->receive(
          EXCEPTIONS
            http_communication_failure = 1
            http_invalid_state        = 2
            http_processing_failed    = 3
            OTHERS                    = 4
        ).

        IF sy-subrc <> 0.
*          RAISE EXCEPTION TYPE cx_static_check.
        ENDIF.

        " Get response
        DATA: lt_response_binary TYPE TABLE OF x255.
        DATA: lv_response_xstring TYPE xstring.

        " Get binary response
        DATA : lv_response TYPE xstring.
        " Get response
        lv_response = lo_http_client->response->get_cdata( ).

        " Convert binary to xstring
        CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
          EXPORTING
            input_length = xstrlen( lv_response )
          IMPORTING
            buffer       = lv_response_xstring
          TABLES
            binary_tab   = lt_response_binary.

        DATA: BEGIN OF ls_response,
                status  TYPE string,
                message TYPE string,
              END OF ls_response.


        " Convert xstring response to string for JSON parsing
        lo_conv = cl_abap_conv_in_ce=>create(
          input = lv_response_xstring
          encoding = 'UTF-8'
        ).

*        DATA(lv_response_string) = lo_conv->read( ).
*
*        /ui2/cl_json=>deserialize(
*          EXPORTING
*            json = lv_response_string
*          CHANGING
*            data = ls_response
*        ).

        " Set success based on response status
*        rv_success = xsdbool( ls_response-status = 'S' ).


*        /ui2/cl_json=>deserialize(
*               EXPORTING
*                 json = lv_response
*               CHANGING
*                 data = ls_response
*             ).

        " Set success based on response status
*        rv_success = xsdbool( ls_response-status = 'S' ).

      CATCH cx_root INTO DATA(lx_root).
*        RAISE EXCEPTION TYPE cx_static_check
*          EXPORTING
*            previous = lx_root.
    ENDTRY.
  ENDMETHOD.


  method SERIALIZE_REQUEST.
  endmethod.


  method VALIDATE_BENEFICIARY.
  endmethod.


  METHOD xstring_to_string.

    DATA: lv_xlen TYPE i,
          lv_hex  TYPE c LENGTH 2.

    lv_xlen = xstrlen( iv_xstring ).

    DO lv_xlen TIMES.
      GET BIT sy-index OF iv_xstring INTO lv_hex.
      rv_string = |{ rv_string }{ lv_hex }|.
    ENDDO.
  ENDMETHOD.
ENDCLASS.
