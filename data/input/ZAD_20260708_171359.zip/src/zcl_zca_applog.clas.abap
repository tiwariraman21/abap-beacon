class ZCL_ZCA_APPLOG definition
  public
  final
  create public .

public section.

  methods CONSTRUCTOR
    importing
      !IV_OBJECT type BALOBJ_D optional
      !IV_SUBOBJECT type BALSUBOBJ optional
      !IV_EXTNUMBER type ANY optional
      !IV_TITLE type BALTITLE optional
      !IV_FROM_DB type ABAP_BOOL optional
      !IV_LOG_HANDLE type BALLOGHNDL optional .
  methods ADD_HEADER
    importing
      !IV_EXTNUMBER type ANY optional .
  methods ADD_EX_MESSAGE
    importing
      !IO_EX type ref to CX_ROOT .
  methods ADD_MESSAGE
    importing
      !IV_MSGID type SYMSGID optional
      !IV_MSGTY type SYMSGTY optional
      !IV_MSGNO type SYMSGNO optional
      !IV_MSGV1 type ANY optional
      !IV_MSGV2 type ANY optional
      !IV_MSGV3 type ANY optional
      !IS_BAPIRET2 type BAPIRET2 optional
      !IS_CONTEXT type BAL_S_CONT optional
      !IV_MSGV4 type ANY optional .
  methods ADD_MESSAGES
    importing
      !IT_BAPIRET2 type BAPIRET2_T optional .
  methods ADD_SY_MESSAGE
    importing
      !IS_CONTEXT type BAL_S_CONT optional .
  methods DISPLAY
    importing
      !IV_SHOW_TREE type ABAP_BOOL optional
      !IV_STANDARD_DISP type ABAP_BOOL optional .
  class-methods WRITE_OUTPUT
    importing
      !IT_LOG_HANDLE type BAL_T_LOGH optional
      !IV_SHOW_SEPARATOR type ABAP_BOOL default ABAP_TRUE .
  class-methods GET_MESSAGE_TYPE_ICON
    importing
      !IV_MSGTY type SYMSGTY
    returning
      value(RV_ICON) type ICON_D .
  methods MESSAGE_EXIST
    returning
      value(RV_EXIST) type ABAP_BOOL .
  class-methods DISPLAY_LOG
    importing
      !IV_OBJECT type BALOBJ_D default TEXT-003
      !IV_SUBOBJECT type BALSUBOBJ optional
      !IV_TITLE type BALTITLE optional
      !IV_SHOW_TREE type ABAP_BOOL optional
      !IV_STANDARD_DISP type ABAP_BOOL optional
      !IV_EXTNUMBER type ANY optional
      !IT_MSG type BAPIRET2_T optional .
  methods SAVE .
protected section.
private section.

  data MV_LOG_HANDLE type BALLOGHNDL .
  data MS_LOG_HDR type BAL_S_LOG .
  data MV_TITLE type BALTITLE .
  data MV_NMESSAGES type I .
  data MV_OBJECT type BALOBJ_D .
  data MV_SUBOBJECT type BALSUBOBJ .
  data MT_LOG_HANDLE type BAL_T_LOGH .
  data GV_DUMMY type STRING .
  constants:
    BEGIN OF gc_icon,
      success TYPE icon_d VALUE '@5B@',
      warning TYPE icon_d VALUE '@5D@',
      error   TYPE icon_d VALUE '@5C@',
      other   TYPE icon_d VALUE '@5F@',
    END OF gc_icon .
  constants GC_STACK_LEVEL type I value '2' ##NO_TEXT.
ENDCLASS.



CLASS ZCL_ZCA_APPLOG IMPLEMENTATION.


  method ADD_EX_MESSAGE.
        CONSTANTS:
      lc_detlevel_9 TYPE c VALUE '9'.
    DATA:
      ls_exc TYPE bal_s_exc,
      lo_ex  TYPE REF TO zcx_zca_exception.

    ls_exc-msgty = cl_esh_adm_constants=>gc_msgty_e.
    ls_exc-exception = io_ex.
    ls_exc-detlevel = lc_detlevel_9.

    CALL FUNCTION 'BAL_LOG_EXCEPTION_ADD'
      EXPORTING
        i_log_handle     = me->mv_log_handle
        i_s_exc          = ls_exc
      EXCEPTIONS
        log_not_found    = 1
        msg_inconsistent = 2
        log_is_full      = 3
        OTHERS           = 4.


    IF sy-subrc <> 0.
      CREATE OBJECT lo_ex.
      lo_ex->append_message_sy( ).
      RAISE EXCEPTION lo_ex.
    ELSE.
      ADD 1 TO mv_nmessages.
    ENDIF.

  endmethod.


  method ADD_HEADER.

    DATA:
      lt_callstack TYPE sys_callst,
      lo_ex        TYPE REF TO zcx_zca_exception.

    CALL FUNCTION 'SYSTEM_CALLSTACK'
      IMPORTING
        et_callstack = lt_callstack.

    DESCRIBE TABLE lt_callstack.
    IF sy-tfill EQ 0.
      ms_log_hdr-alprog = sy-repid.
    ELSE.
      READ TABLE lt_callstack INDEX sy-tfill ASSIGNING FIELD-SYMBOL(<lfs_callstack>).
      IF sy-subrc <> 0.
        ms_log_hdr-alprog = sy-repid.
      ELSE.
        ms_log_hdr-alprog = <lfs_callstack>-progname.
      ENDIF.
    ENDIF.

    ms_log_hdr-extnumber = iv_extnumber.
    ms_log_hdr-object = mv_object.
    ms_log_hdr-subobject = mv_subobject.
    ms_log_hdr-aldate = sy-datum.
    ms_log_hdr-altime = sy-uzeit.
    ms_log_hdr-aluser = sy-uname.
    ms_log_hdr-altcode = sy-tcode.
    ms_log_hdr-almode = sy-batch.
    ms_log_hdr-alchdate = sy-datum.
    ms_log_hdr-alchtime = sy-uzeit.
    ms_log_hdr-alchuser = sy-uname.
    ms_log_hdr-aldate_del = sy-datum.
    ADD 183 TO ms_log_hdr-aldate_del.
    ms_log_hdr-del_before = abap_true.

    CALL FUNCTION 'BAL_LOG_CREATE'
      EXPORTING
        i_s_log                 = ms_log_hdr
      IMPORTING
        e_log_handle            = mv_log_handle
      EXCEPTIONS
        log_header_inconsistent = 1.

    IF sy-subrc <> 0.
      CREATE OBJECT lo_ex.
      lo_ex->append_message_sy( ).
      RAISE EXCEPTION lo_ex.
    ENDIF.

    INSERT mv_log_handle INTO TABLE mt_log_handle.

  endmethod.


  method ADD_MESSAGE.

        DATA:
      ls_msg TYPE bal_s_msg,
      lo_ex  TYPE REF TO zcx_zca_exception.

    IF ( iv_msgty IS INITIAL OR iv_msgid IS INITIAL )
      AND  is_bapiret2 IS INITIAL.

      CREATE OBJECT lo_ex.
      MESSAGE e491(00) INTO gv_dummy.
      lo_ex->append_message_sy( ).
      RAISE EXCEPTION lo_ex.

    ENDIF.

    IF is_bapiret2 IS NOT INITIAL.
      ls_msg-msgty  = is_bapiret2-type.
      ls_msg-msgid  = is_bapiret2-id.
      ls_msg-msgno  = is_bapiret2-number.
      ls_msg-msgv1  = is_bapiret2-message_v1.
      ls_msg-msgv2  = is_bapiret2-message_v2.
      ls_msg-msgv3  = is_bapiret2-message_v3.
      ls_msg-msgv4  = is_bapiret2-message_v4.
    ELSE.
      ls_msg-msgid  = iv_msgid.
      ls_msg-msgty  = iv_msgty.
      ls_msg-msgno  = iv_msgno.
      ls_msg-msgv1  = iv_msgv1.
      ls_msg-msgv2  = iv_msgv2.
      ls_msg-msgv3  = iv_msgv3.
      ls_msg-msgv4  = Iv_msgv4.
    ENDIF.

    IF is_context IS NOT INITIAL.
      ls_msg-context = is_context.
    ENDIF.

    CALL FUNCTION 'BAL_LOG_MSG_ADD'
      EXPORTING
        i_log_handle     = mv_log_handle
        i_s_msg          = ls_msg
      EXCEPTIONS
        log_not_found    = 1
        msg_inconsistent = 2
        log_is_full      = 3
        OTHERS           = 4.

    IF sy-subrc <> 0.
      CREATE OBJECT lo_ex.
      lo_ex->append_message_sy( ).
      RAISE EXCEPTION lo_ex.
    ELSE.
      ADD 1 TO mv_nmessages.
    ENDIF.

  endmethod.


  method ADD_MESSAGES.

    LOOP AT it_bapiret2 ASSIGNING FIELD-SYMBOL(<lfs_msg>).
      me->add_message( is_bapiret2 = <lfs_msg> ).
    ENDLOOP.

  endmethod.


  method ADD_SY_MESSAGE.
        me->add_message( iv_msgid = sy-msgid
                     iv_msgno = sy-msgno
                     iv_msgty = sy-msgty
                     iv_msgv1 = sy-msgv1
                     iv_msgv2 = sy-msgv2
                     iv_msgv3 = sy-msgv3
                     iv_msgv4 = sy-msgv4
                     is_context = is_context ).

  endmethod.


  method CONSTRUCTOR.

    DATA:
          lo_ex TYPE REF TO zcx_zca_exception.

    mv_object = iv_object.
    mv_subobject = iv_subobject.

    IF iv_from_db EQ abap_false.

      IF iv_title IS INITIAL.
        mv_title = TEXT-000.
      ELSE.
        mv_title = iv_title.
      ENDIF.

      IF iv_extnumber IS INITIAL.
        CREATE OBJECT lo_ex.
        MESSAGE e491(00) INTO gv_dummy.
        lo_ex->append_message_sy( ).
        RAISE EXCEPTION lo_ex.
      ENDIF.

      me->add_header( iv_extnumber = iv_extnumber ).
    ELSE.
      IF iv_log_handle IS NOT INITIAL.
        CALL FUNCTION 'BAL_LOG_HDR_READ'
          EXPORTING
            i_log_handle  = iv_log_handle
          IMPORTING
            e_s_log       = ms_log_hdr
          EXCEPTIONS
            log_not_found = 1
            OTHERS        = 2.
        IF sy-subrc <> 0.
          CREATE OBJECT lo_ex.
          lo_ex->append_message_sy( ).
          RAISE EXCEPTION lo_ex.
        ELSE.
          IF iv_title IS INITIAL.
            me->mv_title = TEXT-000.
          ELSE.
            me->mv_title = iv_title.
          ENDIF.
          mv_log_handle = iv_log_handle.
        ENDIF.
      ENDIF.
    ENDIF.


  endmethod.


  method DISPLAY.

        DATA:
      ls_profile_single TYPE bal_s_prof,
      ls_profile        TYPE bal_s_prof,
      lo_ex             TYPE REF TO zcx_zca_exception.

    CHECK:  mv_nmessages > 0,
            mv_log_handle IS NOT INITIAL.

    IF sy-batch IS INITIAL.
      IF iv_standard_disp = abap_true.
        CALL FUNCTION 'BAL_DSP_PROFILE_STANDARD_GET'
          IMPORTING
            e_s_display_profile = ls_profile.

        ls_profile-tree_adjst  = abap_true.
        ls_profile-show_all = abap_true.

      ELSE.
        CALL FUNCTION 'BAL_DSP_PROFILE_POPUP_GET'
          IMPORTING
            e_s_display_profile = ls_profile_single.
        IF iv_show_tree = abap_true.
          CALL FUNCTION 'BAL_DSP_PROFILE_SINGLE_LOG_GET'
            IMPORTING
              e_s_display_profile = ls_profile_single.
          ls_profile_single-start_col = ls_profile-start_col.
          ls_profile_single-start_row = ls_profile-start_row.
          ls_profile_single-end_col   = ls_profile-end_col.
          ls_profile_single-end_row   = ls_profile-end_row.
          ls_profile = ls_profile_single.
        ENDIF.
      ENDIF.

      ls_profile-title = me->mv_title.
      ls_profile-use_grid = abap_true.

      CALL FUNCTION 'BAL_DSP_LOG_DISPLAY'
        EXPORTING
          i_s_display_profile  = ls_profile
          i_t_log_handle       = mt_log_handle
        EXCEPTIONS
          profile_inconsistent = 1
          internal_error       = 2
          no_data_available    = 3
          no_authority         = 4
          OTHERS               = 5.

      IF sy-subrc <> 0.
        CREATE OBJECT lo_ex.
        lo_ex->append_message_sy( ).
        RAISE EXCEPTION lo_ex.
      ENDIF.
    ELSE.
      write_output( it_log_handle = mt_log_handle ).
    ENDIF.

  endmethod.


  method DISPLAY_LOG.

        CONSTANTS:
    lc_extnum_dummy TYPE char10 VALUE '__DUMM'.

    DATA:
      lr_log       TYPE REF TO zcl_zca_applog,
      lv_extnumber TYPE string,
      lo_ex        TYPE REF TO zcx_zca_exception.

    TRY.
        IF iv_extnumber IS NOT INITIAL.
          lv_extnumber = iv_extnumber.
        ELSE.
          lv_extnumber = lc_extnum_dummy.
        ENDIF.

        CREATE OBJECT lr_log
          EXPORTING
            iv_object    = iv_object
            iv_subobject = iv_subobject
            iv_extnumber = iv_extnumber
            iv_title     = iv_title.

        lr_log->add_messages( it_msg ).

        lr_log->display( ).

      CATCH zcx_zca_exception INTO lo_ex.
*        lo_ex->display( ).
    ENDTRY.


  endmethod.


  method GET_MESSAGE_TYPE_ICON.

        CASE iv_msgty.
      WHEN cl_esh_adm_constants=>gc_msgty_s OR cl_esh_adm_constants=>gc_msgty_i.
        rv_icon = gc_icon-success.
      WHEN cl_esh_adm_constants=>gc_msgty_w.
        rv_icon = gc_icon-warning.
      WHEN cl_esh_adm_constants=>gc_msgty_e.
        rv_icon = gc_icon-error.
      WHEN OTHERS.
        rv_icon = gc_icon-other.
    ENDCASE.

  endmethod.


  method MESSAGE_EXIST.
        IF mv_nmessages > 0.
      rv_exist = abap_true.
    ENDIF.
  ENDMETHOD.


  method SAVE.
        DATA:
          lt_log_handle TYPE bal_t_logh.

    APPEND mv_log_handle TO lt_log_handle.

    CALL FUNCTION 'BAL_DB_SAVE'
      EXPORTING
        i_t_log_handle   = lt_log_handle
      EXCEPTIONS
        log_not_found    = 1
        save_not_allowed = 2
        numbering_error  = 3
        OTHERS           = 4.
    IF sy-subrc <> 0.
    ELSE.
    ENDIF.

  endmethod.


  method WRITE_OUTPUT.

    TYPES:
      BEGIN OF lty_hdr,
        log_handle TYPE balloghndl,
        hdr        TYPE bal_s_log,
      END OF lty_hdr.

    DATA:
      lt_msg_handle    TYPE bal_t_msgh,
      lv_msg_text(300) TYPE c,
      ls_msg           TYPE bal_s_msg,
      lv_icon          TYPE icon_d,
      lv_log_handle    TYPE balloghndl,
      ls_bal_s_log     TYPE bal_s_log,
      lt_hdr           TYPE STANDARD TABLE OF lty_hdr.

    CALL FUNCTION 'BAL_GLB_SEARCH_MSG'
      EXPORTING
        i_t_log_handle = it_log_handle
      IMPORTING
        e_t_msg_handle = lt_msg_handle
      EXCEPTIONS
        msg_not_found  = 1
        OTHERS         = 2.

    CHECK sy-subrc = 0.
    SORT lt_hdr BY log_handle.
    LOOP AT lt_msg_handle ASSIGNING FIELD-SYMBOL(<lfs_msghandle>).
      CALL FUNCTION 'BAL_LOG_MSG_READ'
        EXPORTING
          i_s_msg_handle = <lfs_msghandle>
        IMPORTING
          e_s_msg        = ls_msg
          e_txt_msg      = lv_msg_text
        EXCEPTIONS
          log_not_found  = 1
          msg_not_found  = 2
          OTHERS         = 3.

      CHECK sy-subrc = 0.
      READ TABLE lt_hdr WITH KEY log_handle = <lfs_msghandle>-log_handle BINARY SEARCH
        ASSIGNING FIELD-SYMBOL(<lfs_hdr>).

      IF sy-subrc <> 0.

        CALL FUNCTION 'BAL_LOG_HDR_READ'
          EXPORTING
            i_log_handle  = <lfs_msghandle>-log_handle
          IMPORTING
            e_s_log       = ls_bal_s_log
          EXCEPTIONS
            log_not_found = 1
            OTHERS        = 2.

        IF sy-subrc = 0.
          APPEND INITIAL LINE TO lt_hdr ASSIGNING <lfs_hdr>.
          CLEAR <lfs_hdr>.
          <lfs_hdr>-log_handle = <lfs_msghandle>-log_handle.
          <lfs_hdr>-hdr = ls_bal_s_log.
        ENDIF.
      ENDIF.

      IF iv_show_separator = abap_true AND lv_log_handle <> <lfs_msghandle>-log_handle.
        ULINE.
        WRITE:/ <lfs_hdr>-hdr-extnumber.
        lv_log_handle = <lfs_msghandle>-log_handle.

      ENDIF.

      lv_icon = get_message_type_icon( ls_msg-msgty ).
      WRITE: /1(3) lv_icon AS ICON, 5(*) lv_msg_text.
    ENDLOOP.


  endmethod.
ENDCLASS.
