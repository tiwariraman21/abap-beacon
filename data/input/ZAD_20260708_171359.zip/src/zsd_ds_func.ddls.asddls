@AbapCatalog.sqlViewName: 'ZSD_DS_FUNC_V'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Decimal Function'
define view ZSD_DS_FUNC as select from vbak 
    {
    key vbeln as Sales_Doc,
    netwr as Original_Val,
    
    // DECIMAL_SHIFT
    DECIMAL_SHIFT( 
        amount => netwr,
        currency => cast( '0 ' as abap.cuky(5) ) 
    ) as DS_0,
    
    DECIMAL_SHIFT( 
        amount => netwr,
        currency => cast( '1 ' as abap.cuky(5) ) 
    ) as DS_1,
    
    DECIMAL_SHIFT( 
        amount => netwr,
        currency => cast( '2 ' as abap.cuky(5) ) 
    ) as DS_2,
    
    DECIMAL_SHIFT( 
        amount => netwr,
        currency => cast( '3 ' as abap.cuky(5) ) 
    ) as DS_3,
    
    DECIMAL_SHIFT( 
        amount => netwr,
        currency => cast( '4 ' as abap.cuky(5) ) 
    ) as DS_4,
    
    DECIMAL_SHIFT( 
        amount => netwr,
        currency => cast( '5 ' as abap.cuky(5) ) 
    ) as DS_5
    
    
    
    
    
        
    }
    where vbtyp = 'C'
    and   waerk = 'INR'
    and   netwr <> 0
