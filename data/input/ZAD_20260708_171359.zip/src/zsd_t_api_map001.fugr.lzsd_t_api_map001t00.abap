*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZSD_T_API_MAP001................................*
DATA:  BEGIN OF STATUS_ZSD_T_API_MAP001              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSD_T_API_MAP001              .
CONTROLS: TCTRL_ZSD_T_API_MAP001
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZSD_T_API_MAP001              .
TABLES: ZSD_T_API_MAP001               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
