*&---------------------------------------------------------------------*
*& Include          ZRFI_VENDOR_AGEING_NEW_SEL
*&---------------------------------------------------------------------*
Tables: bseg, lfa1, bsik.
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.

  SELECT-OPTIONS: s_bukrs FOR BSEG-bukrs MODIF ID rd1 DEFAULT 'AESL',
                  s_lifnr FOR lfa1-lifnr MODIF ID rd1," OBLIGATORY,
                  s_prctr FOR bsik-prctr MODIF ID rd1,
*                s_gsber FOR bsik-gsber MODIF ID rd1,
                  s_saknr FOR bsik-saknr,
                  s_budat FOR sy-datum NO-EXTENSION DEFAULT sy-datum OBLIGATORY NO INTERVALS,
                  s_umskz FOR bseg-umskz MODIF ID rd1,
                  s_belnr FOR bseg-belnr MODIF ID rd1,
                  s_gsber FOR bseg-gsber MODIF ID rd1.

  SELECTION-SCREEN SKIP.
  PARAMETERS: r_litem  RADIOBUTTON GROUP g2.
*SELECTION-SCREEN SKIP.
  PARAMETERS: r_summre RADIOBUTTON GROUP g2.
SELECTION-SCREEN END OF  BLOCK b1.
SELECTION-SCREEN SKIP.
SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-003.
  SELECTION-SCREEN : BEGIN OF LINE.
    SELECTION-SCREEN : COMMENT (31) TEXT-002.
    PARAMETERS: agedays1(4) TYPE n DEFAULT '0030'.
    PARAMETERS: agedays2(4) TYPE n DEFAULT '0060'.
    PARAMETERS: agedays3(4) TYPE n DEFAULT '0090'.
    PARAMETERS: agedays4(4) TYPE n DEFAULT '0120'.
    PARAMETERS: agedays5(4) TYPE n DEFAULT '0180'.
*PARAMETERS: agedays6(4) TYPE n DEFAULT '0180'.
*PARAMETERS: agedays7(4) TYPE n DEFAULT '0365'.
*PARAMETERS: agedays8(4) TYPE n DEFAULT '0730'.
    PARAMETERS: agedays9(5) TYPE n NO-DISPLAY.
  SELECTION-SCREEN : END OF LINE.

  SELECTION-SCREEN SKIP.
  PARAMETERS: r_inv RADIOBUTTON GROUP g1,
              r_due RADIOBUTTON GROUP g1 DEFAULT 'X',
              r_bse RADIOBUTTON GROUP g1,
              r_uac RADIOBUTTON GROUP g1,
              r_nd  RADIOBUTTON GROUP g1.

  SELECTION-SCREEN SKIP.
  PARAMETERS : p_dwn  TYPE c AS CHECKBOX.


SELECTION-SCREEN END OF  BLOCK b2.
