interface ZAIF_II_FLIGHTBOOKING_IN
  public .


  methods POSTBOOKINGS_01
    importing
      !INPUT type SXIDAL_FBO_REQUEST_MT
    raising
      CX_SXIDAL_TECHNICAL_PROBLEMS .
endinterface.
