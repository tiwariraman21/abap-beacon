class ZCL_ZSD_SALESORDER_CRE_MPC_EXT definition
  public
  inheriting from ZCL_ZSD_SALESORDER_CRE_MPC
  create public .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZSD_SALESORDER_CRE_MPC_EXT IMPLEMENTATION.
ENDCLASS.
