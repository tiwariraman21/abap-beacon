@AbapCatalog.sqlViewName: 'ZSD_DT_CONV_V'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'SQL Date & Time Functions'
define view ZSD_DT_CONV as select from vbak
     {
     key vbeln as Sales_Doc,
     erdat as Created_Date, 
     erzet as Created_Time,
     
     // Current System time stamp
     TSTMP_CURRENT_UTCTIMESTAMP( ) as C_TStamp,
     
     // Split Date from Time stamp 
     TSTMP_TO_DATS( 
         TSTMP_CURRENT_UTCTIMESTAMP( ) , // Current time stamp
         ABAP_SYSTEM_TIMEZONE( $session.client, 'NULL' ), // Current system time zone
         $session.client,  // Current client
         'NULL' // Error
     ) as to_date,
     
     // Split Time from Time stamp
     TSTMP_TO_TIMS(
         TSTMP_CURRENT_UTCTIMESTAMP( ) , // Current time stamp
         ABAP_SYSTEM_TIMEZONE( $session.client, 'NULL' ), // Current system time zone
         $session.client,  // Current client
         'NULL' // Error
     ) as to_time,
     
     // Summer Time Indicator - 'X'
     TSTMP_TO_DST( 
         TSTMP_CURRENT_UTCTIMESTAMP( ) , // Current time stamp
         ABAP_SYSTEM_TIMEZONE( $session.client, 'NULL' ), // Current system time zone
         $session.client,  // Current client
         'NULL' // Error
     ) as Summer_Ind,
     
     
     // Generate time stamp based on Date & Time
     DATS_TIMS_TO_TSTMP(
         erdat, 
         erzet, 
         ABAP_SYSTEM_TIMEZONE( $session.client, 'NULL' ), // Current system time zone
         $session.client,
         'NULL' // Error
     ) as N_TStamp
      
        
    }
    where vbtyp = 'C'
