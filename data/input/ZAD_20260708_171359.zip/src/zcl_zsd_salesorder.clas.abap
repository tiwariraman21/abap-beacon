class ZCL_ZSD_SALESORDER definition
  public
  final
  create public .

public section.

  class-data GV_INSTANCE type ref to ZCL_ZSD_SALESORDER .

  methods CHECK_SF_REF_ALREADY_EXISTS
    importing
      !IV_SF_REF type CHAR20
    returning
      value(RV_VBELN_VA) type VBELN_VA .
  class-methods GET_INSTANCE
    returning
      value(RO_INSTANCE) type ref to ZCL_ZSD_SALESORDER .
  methods PROCESS_SINGLE_SO
    changing
      !CS_DEEP_ENTITY type ZSD_S_SO_HEADER_EXP .
  methods GET_MAPPINGS .
  methods PREPARE_BAPI_PARAMETERS .
  methods TRANSFER_ODATA_TO_BAPI
    importing
      !IV_BAPI_STRUCT type STRUKNAME optional
      !IV_ODATA_ENTITY type STRING optional
      !IV_BAPI_TABLE type STRUKNAME optional .
  methods PREPARE_BAPIX_PARAMETERS
    importing
      !IV_BAPI_STRUCT type STRUKNAME optional
      !IT_BAPI_TABLE type STRUKNAME optional
      !IV_BAPIX_STRUCT type STRUKNAME optional
      !IT_BAPIX_TABLE type STRUKNAME optional .
  methods SPLIT_LONG_TEXT .
*  methods BAPI_CONVERSIONS .
protected section.
private section.

  data MS_DEEP_ENTITY type ZSD_S_SO_HEADER_EXP .
  data MT_API_MAP001 type ZSD_TT_API_MAP001 .
  data:
    BEGIN OF ms_bapi_elements,
      ms_bapisdhd1          TYPE strukname VALUE 'MS_BAPISDHD1',
      mt_bapisditm          TYPE strukname VALUE 'MT_BAPISDITM',
      mt_bapiparnr          TYPE strukname VALUE 'MT_BAPIPARNR',
      mt_bapischdl          TYPE strukname VALUE 'MT_BAPISCHDL',
      mt_bapicond           TYPE strukname VALUE 'MT_BAPICOND',
      mt_bapisdtext         TYPE strukname VALUE 'MT_BAPISDTEXT',
      mt_bapisditmx         TYPE strukname VALUE 'MT_BAPISDITMX',
      mt_bapischdlx         TYPE strukname VALUE 'MT_BAPISCHDLX',
      mt_bapicondx          TYPE strukname VALUE 'MT_BAPICONDX',
      ms_deep_entity        TYPE strukname VALUE 'MS_DEEP_ENTITY',
      ms_bapisdhd1x         TYPE strukname VALUE 'MS_BAPISDHD1X',
      mt_bapisdhd_out       TYPE strukname VALUE 'MT_BAPISDHD_OUT',
      mt_bapisdit_out       TYPE strukname VALUE 'MT_BAPISDIT_OUT',
      mt_bapisdhedu_out     TYPE strukname VALUE 'MT_BAPISDHEDU_OUT',
      mt_bapisdpart_out     TYPE strukname VALUE 'MT_BAPISDPART_OUT',
      mt_bapisdhdst_out     TYPE strukname VALUE 'MT_BAPISDHDST_OUT',
      mt_bapisditst_out     TYPE strukname VALUE 'MT_BAPISDITST_OUT',
      mt_bapisdcond_out     TYPE strukname VALUE 'MT_BAPISDCOND_OUT',
      mt_bapisdtehd_out     TYPE strukname VALUE 'MT_BAPISDTEHD_OUT',
      mt_bapitextli_out     TYPE strukname VALUE 'MT_BAPITEXTLI_OUT',
      mt_bapicondhd_out     TYPE strukname VALUE 'MT_BAPICONDHD_OUT',
      mt_bapicondit_out     TYPE strukname VALUE 'MT_BAPICONDIT_OUT',
      ms_bapisdhd_out       TYPE strukname VALUE 'MS_BAPISDHD_OUT',
      mt_bapidlvitem_out    TYPE strukname VALUE 'MT_BAPIDLVITEM_OUT',
      mt_bapidlvhdr_out     TYPE strukname VALUE 'MT_BAPIDLVHDR_OUT',
      mt_bapidlvhdrsts_out  TYPE strukname VALUE 'MT_BAPIDLVHDRSTS_OUT',
      mt_bapidlvitemsts_out TYPE strukname VALUE 'MS_BAPIDLVITEMSTS_OUT',
    END OF ms_bapi_elements .
  data:
    BEGIN OF ms_odata_elements,
      ms_deep_entity   TYPE string VALUE 'ms_deep_entity',
      so_itemset       TYPE string VALUE 'ms_deep_entity-so_itemset',
      so_hpartnerset   TYPE string VALUE 'ms_deep_entity-so_hpartnerset',
      so_slineset      TYPE string VALUE 'ms_deep_entity-so_slineset',
      so_iprelementset TYPE string VALUE 'ms_deep_entity-so_iprelementset',
      so_htextset      TYPE string VALUE 'ms_deep_entity-so_htextset',
      so_messagesset   TYPE string VALUE 'ms_deep_entity-so_messagesset',
      so_deliveryset   TYPE string VALUE 'ms_deep_entity-so_deliveryset',
    END OF ms_odata_elements .
  data:
    BEGIN OF ms_entity_types,
      so_header  TYPE string VALUE 'SO_Header',
      so_request TYPE string VALUE 'SO_Request',
    END OF ms_entity_types .
  data:
    BEGIN OF ms_cdobjectcl,
      lieferung TYPE cdhdr-objectclas VALUE 'LIEFERUNG',
      verkbeleg TYPE cdhdr-objectclas VALUE 'VERKBELEG',
    END OF ms_cdobjectcl .
  data MT_BAPISDITMX type COD_T_BAPISDITMX .
  data:
    BEGIN OF ms_abstract_name,
      bapiupdate TYPE string VALUE '\TYPE=BAPIUPDATE',
    END OF ms_abstract_name .
  data MT_BAPIPARNR type COD_T_BAPIPARNR .
  data MT_BAPIPAREX type BAPIPAREX_T .
  constants MC_PO_METHOD_SF type BSARK value 'SF' ##NO_TEXT.
  data MS_BAPISDHD1 type BAPISDHD1 .
  data MT_BAPISDITM type COD_T_BAPISDITM .
  data:
    BEGIN OF ms_refdoc_cat,
        CONTRACT TYPE VBTYPL_V  VALUE 'G',
        END OF ms_refdoc_cat .
  data MT_BAPISCHDL type COD_T_BAPISCHDL .
  data MT_BAPISDTEXT type BAPISDTEXT_T .
  data MT_BAPICOND type COD_T_BAPICOND .
  constants MC_TVARVC_SO_TYPE type RVARI_VNAM value 'ZSD_SF_INT' ##NO_TEXT.
  data MT_RNG_AUART type SACO_AUART_RANGES_TAB .
  constants MC_TVARVC_SO_TYPE2 type RVARI_VNAM value 'ZSD_TYPE' ##NO_TEXT.
  data MT_RNG_AUART2 type SACO_AUART_RANGES_TAB .
  data MS_BAPISDHD1X type BAPISDHD1X .
  data MT_BAPISCHDLX type COD_T_BAPISCHDLX .
  data MT_BAPICONDX type COD_T_BAPICONDX .
  data MT_BAPIRET2 type BAPIRET2_TT .
  data MV_VBELN type VBELN .
  data MT_VBELN_OUT type SHP_SALES_KEY_T .
  data:
    BEGIN OF ms_updkz,
         update type updkz_d value 'U',
         DELETE type updkz_d value 'D',
           END OF MS_updkz .
  data:
    begin of MS_USER_STATUS,
          rel type j_txt04 value 'REL',
         END OF MS_USER_STATUS .
  data MT_BAPISDHD_OUT type WISO_T_SDHD .
  data MS_BAPISDHD_OUT type BAPISDHD .
  data:
    BEGIN OF MS_ABAP_TYPEKIND ,
          P TYPE ABAP_TYPEKIND VALUE 'P',
         END OF MS_ABAP_TYPEKIND .
  data MO_BALLOG type ref to ZCL_ZCA_APPLOG .
  constants MC_LOG_OBJECT type BALOBJ_D value 'ZSF_API_LOG' ##NO_TEXT.
  constants MC_POST_LOG_SUBOBJECT type BALSUBOBJ value 'ZSD_SO_POST' ##NO_TEXT.
  constants MC_LOG_TITLE type BALTITLE value 'Sales Order API LOG' ##NO_TEXT.

  methods APPEND_SY_MESSAGE_TO_BAPIRET2
    changing
      !CT_BAPIRET2 type BAPIRET2_T optional .
  methods COPY_BAPIRET_TO_MESSAGE .
  methods BAPI_CONVERSIONS .
  methods SO_TYPE_RNG_PREPARE .
  methods CALL_BAPI_CREATE .
  methods CLEAR_DELIVERY_BLOCK .
  methods UPDATE_JEST_STATUS .
  methods RELEASE_ORDER .
  methods WAIT_FOR_LOMOSOFT_STAT_UPDATE .
  methods PREPARE_ODATA_FEEDBACK .
  methods ODATA_GET_EXTRA_DATA .
  methods TRANSFER_BAPI_TO_ODATA
    importing
      !IV_BAPI_STRUCT type STRUKNAME optional
      !IV_BAPI_TABLE type STRUKNAME optional
      !IV_ODATA_ENTITY type STRING optional .
ENDCLASS.



CLASS ZCL_ZSD_SALESORDER IMPLEMENTATION.


  METHOD append_sy_message_to_bapiret2.
    APPEND INITIAL LINE TO ct_bapiret2 ASSIGNING FIELD-SYMBOL(<lfs_bapiret2>).
    CLEAR <lfs_bapiret2>.
    <lfs_bapiret2>-id = sy-msgid.
    <lfs_bapiret2>-type = sy-msgty.
    <lfs_bapiret2>-number = sy-msgno.
    <lfs_bapiret2>-message_v1 = sy-msgv1.
    <lfs_bapiret2>-message_v2 = sy-msgv2.
    <lfs_bapiret2>-message_v3 = sy-msgv3.
    <lfs_bapiret2>-message_v4 = sy-msgv4 .
    MESSAGE ID <lfs_bapiret2>-id
            TYPE <lfs_bapiret2>-type
            NUMBER <lfs_bapiret2>-number
            WITH <lfs_bapiret2>-message_v1 <lfs_bapiret2>-message_v2 <lfs_bapiret2>-message_v3 <lfs_bapiret2>-message_v4
            INTO <lfs_bapiret2>-message.
  ENDMETHOD.


  method BAPI_CONVERSIONS.


     DATA:
      ls_bape_vbak  TYPE bape_vbak,
      ls_bape_vbakx TYPE bape_vbakx,
      ls_bape_vbap  TYPE bape_vbap,
      ls_bape_vbapx TYPE bape_vbapx.
    CONSTANTS:
      lc_bape_vbak  TYPE te_struc VALUE 'BAPE_VBAK',
      lc_bape_vbakx TYPE te_struc VALUE 'BAPE_VBAKX',
      lc_bape_vbap  TYPE te_struc VALUE 'BAPE_VBAP',
      lc_bape_vbapx TYPE te_struc VALUE 'BAPE_VBAPX',
      lc_kappl_v    TYPE kappl VALUE 'V',
      lc_krech_a    TYPE krech VALUE 'A',
      lc_krech_h    TYPE krech VALUE 'H',
      lc_krech_i    TYPE krech VALUE 'I'.


    LOOP AT mt_bapiparnr ASSIGNING FIELD-SYMBOL(<lfs_bapiparnr>).
    ENDLOOP.

* Processing header extension
    CLEAR ls_bape_vbak.
    APPEND INITIAL LINE TO mt_bapiparex ASSIGNING FIELD-SYMBOL(<lfs_bapiparex>).
    CLEAR <lfs_bapiparex>.
*    ls_bape_vbak-zz_refno_ext   = ms_deep_entity-salesforcereference. for now didnt add any custom field in ideas
    <lfs_bapiparex>-structure    = lc_bape_vbak.
    <lfs_bapiparex>-valuepart1   = ls_bape_vbak.

    CLEAR ls_bape_vbakx.
    APPEND INITIAL LINE TO mt_bapiparex ASSIGNING <lfs_bapiparex>.
    CLEAR <lfs_bapiparex>.
*    ls_bape_vbakx-zz_refno_ext  = abap_true. for now didnt add any custom field in ideas
    <lfs_bapiparex>-structure    = lc_bape_vbakx.
    <lfs_bapiparex>-valuepart1   = ls_bape_vbakx.

    ms_bapisdhd1-po_method = mc_po_method_sf.

    "Payment method from header if empty.
    LOOP AT mt_bapisditm ASSIGNING FIELD-SYMBOL(<lfs_bapisditm>).
      CLEAR <lfs_bapisditm>-vw_uepos.
      IF <lfs_bapisditm>-pymt_meth IS INITIAL.
        <lfs_bapisditm>-pymt_meth = ms_bapisdhd1-pymt_meth.
      ENDIF.
* Processing item extension
      IF ms_bapisdhd1-refdoc_cat_long = ms_refdoc_cat-contract.
        CLEAR ls_bape_vbap.
        APPEND INITIAL LINE TO mt_bapiparex ASSIGNING <lfs_bapiparex>.
        CLEAR <lfs_bapiparex>.
        ls_bape_vbap-posnr            = <lfs_bapisditm>-itm_number.
*        ls_bape_vbap-oicontnr         = <lfs_bapisditm>-ref_doc.   NEED TO APPEND CUSTOM FIELDS IN STND STRUCTURE SO NOT ADDING FOR NW
*        ls_bape_vbap-oic_kmpos        = <lfs_bapisditm>-ref_doc_it.
        <lfs_bapiparex>-structure     = lc_bape_vbap.
        <lfs_bapiparex>-valuepart1    = ls_bape_vbap.

        CLEAR ls_bape_vbapx.
        APPEND INITIAL LINE TO mt_bapiparex ASSIGNING <lfs_bapiparex>.
        CLEAR <lfs_bapiparex>.
        ls_bape_vbapx-posnr           = <lfs_bapisditm>-itm_number.
*        ls_bape_vbapx-oicontnr        = abap_true.
*        ls_bape_vbapx-oic_kmpos       = abap_true.
        <lfs_bapiparex>-structure     = lc_bape_vbapx.
        <lfs_bapiparex>-valuepart1    = ls_bape_vbapx.
      ENDIF.
    ENDLOOP.

    "Is Schedule Line is not passed from SF - assume full quantity and current date for it
    SORT mt_bapischdl BY itm_number ASCENDING.
    LOOP AT mt_bapisditm ASSIGNING <lfs_bapisditm>.
      READ TABLE mt_bapischdl WITH KEY itm_number = <lfs_bapisditm>-itm_number TRANSPORTING NO FIELDS BINARY SEARCH.
      IF sy-subrc <> 0.
        APPEND INITIAL LINE TO mt_bapischdl ASSIGNING FIELD-SYMBOL(<lfs_bapischdl>).
        CLEAR <lfs_bapischdl>.
        <lfs_bapischdl>-itm_number = <lfs_bapisditm>-itm_number.
        <lfs_bapischdl>-req_qty = <lfs_bapisditm>-target_qty.
        <lfs_bapischdl>-req_date = sy-datum.
      ENDIF.
    ENDLOOP.
    LOOP AT mt_bapisdtext ASSIGNING FIELD-SYMBOL(<lfs_bapisdtext>).
      IF <lfs_bapisdtext>-langu IS INITIAL.
        <lfs_bapisdtext>-langu = sy-langu.
      ENDIF.
    ENDLOOP.

    "Pricing condition for % value correction
    SELECT kschl,krech
      FROM t685a
      INTO TABLE @DATA(lt_t685a)
      WHERE kappl = @lc_kappl_v.
    IF sy-subrc = 0.
      SORT lt_t685a BY kschl.
    ENDIF.
    LOOP AT mt_bapicond ASSIGNING FIELD-SYMBOL(<lfs_bapicond>).
      READ TABLE lt_t685a ASSIGNING FIELD-SYMBOL(<lfs_t685a>) WITH KEY kschl = <lfs_bapicond>-cond_type.
      IF sy-subrc EQ 0.
        CASE <lfs_t685a>-krech.
          WHEN lc_krech_a OR lc_krech_h OR lc_krech_i.
            IF <lfs_bapicond>-currency IS NOT INITIAL.
              <lfs_bapicond>-cond_value = <lfs_bapicond>-cond_value * 10.
            ENDIF.
          WHEN OTHERS.
            "do nothing.
        ENDCASE.
      ENDIF.
    ENDLOOP.


  endmethod.


  method CALL_BAPI_CREATE.
     DATA: lv_vbeln    TYPE vbeln_va,
          lt_bapiret2 TYPE bapiret2_tt,
          lv_source   TYPE char2.

****************    Added By Anjali as price confirmation condition ZFPD is not getting determined in routine RV64A901
    CONSTANTS: lc_sf TYPE char2 VALUE 'SF',
               lc_id type char6 value 'SFID'.
    lv_source = lc_sf.
    EXPORT lv_source FROM  lv_source TO MEMORY ID lc_id.
****************    end of Adding By Anjali on 07.02.2024


    CALL FUNCTION 'BAPI_SALESORDER_CREATEFROMDAT2'
      EXPORTING
*       SALESDOCUMENTIN      =
        order_header_in      = ms_bapisdhd1
        order_header_inx     = ms_bapisdhd1x
*       SENDER               =
*       BINARY_RELATIONSHIPTYPE       =
*       INT_NUMBER_ASSIGNMENT         =
*       BEHAVE_WHEN_ERROR    =
*       LOGIC_SWITCH         =
*       TESTRUN              =
*       CONVERT              = ' '
      IMPORTING
        salesdocument        = lv_vbeln
      TABLES
        return               = lt_bapiret2
        order_items_in       = mt_bapisditm
        order_items_inx      = mt_bapisditmx
        order_partners       = mt_bapiparnr
        order_schedules_in   = mt_bapischdl
        order_schedules_inx  = mt_bapischdlx
        order_conditions_in  = mt_bapicond
        order_conditions_inx = mt_bapicondx
*       ORDER_CFGS_REF       =
*       ORDER_CFGS_INST      =
*       ORDER_CFGS_PART_OF   =
*       ORDER_CFGS_VALUE     =
*       ORDER_CFGS_BLOB      =
*       ORDER_CFGS_VK        =
*       ORDER_CFGS_REFINST   =
*       ORDER_CCARD          =
        order_text           = mt_bapisdtext
*       ORDER_KEYS           =
        extensionin          = mt_bapiparex
*       PARTNERADDRESSES     =
*       extensionex          = mt_bapiparex
*       NFMETALLITMS         =
      .

    APPEND LINES OF lt_bapiret2 TO mt_bapiret2.
    TRY.
*        mo_ballog->add_messages( lt_bapiret2 ).
*      CATCH zcx_zca_exception INTO DATA(lo_ex).
    ENDTRY.

    IF lv_vbeln IS NOT INITIAL.
      mv_vbeln = lv_vbeln.
      CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
        EXPORTING
          wait = abap_true.
      APPEND INITIAL LINE TO mt_vbeln_out ASSIGNING FIELD-SYMBOL(<lfs_vbeln>).
      <lfs_vbeln>-vbeln = mv_vbeln.
    ENDIF.

    me->clear_delivery_block( ).
*    me->update_jest_status( ).
    IF ms_deep_entity-autoreleaseorder = abap_true.
      me->release_order( ).
    ENDIF.
    clear lv_Source.
    FREE MEMORY ID lc_id.
  ENDMETHOD.


  method CHECK_SF_REF_ALREADY_EXISTS.
*    select single vbeln into @rv_vbeln_va  from vbak where zz_ref_ext = @iv_sf_ref.
*      if sy-subrc <> 0.
*        clear rv_vbeln_va.
*      endif.
  endmethod.


  method CLEAR_DELIVERY_BLOCK.

     DATA: ls_so_header_in TYPE bapisdh1.
    DATA: ls_so_header_inx TYPE bapisdh1x.

    ls_so_header_inx-updateflag = ms_updkz-update.
    ls_so_header_inx-dlv_block = abap_true.

    CALL FUNCTION 'BAPI_SALESORDER_CHANGEBOS'
      EXPORTING
        salesdocument  = mv_vbeln
        orderheaderin  = ls_so_header_in
        orderheaderinx = ls_so_header_inx.

    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        wait = abap_true.
  endmethod.


  METHOD copy_bapiret_to_message.
    CONSTANTS: lc_separator TYPE char3 VALUE ` | `.
    LOOP AT mt_bapiret2 ASSIGNING FIELD-SYMBOL(<lfs_bapiret2>).
      APPEND INITIAL LINE TO ms_deep_entity-so_messagesset ASSIGNING FIELD-SYMBOL(<lfs_message>).
      CLEAR <lfs_message>.
      <lfs_message> = CORRESPONDING #( <lfs_bapiret2> ).
      <lfs_message>-mandt = sy-mandt.
      <lfs_message>-salesorder = mv_vbeln.
      IF <lfs_bapiret2>-type = cl_esh_adm_constants=>gc_msgty_e OR <lfs_bapiret2>-type = cl_esh_adm_constants=>gc_msgty_a.
        ms_deep_entity-message = ms_deep_entity-message && space && <lfs_bapiret2>-message && lc_separator.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


  method GET_INSTANCE.

    IF gv_instance IS INITIAL.
      CREATE OBJECT gv_instance.
    ENDIF.

    ro_instance = gv_instance.
  endmethod.


  method GET_MAPPINGS.

     SELECT  mandt
            bapi_struct
            bapi_field
            odata_struct
            odata_field
      FROM  zsd_t_api_map001 INTO TABLE mt_api_map001
      WHERE active = abap_true.                     "#EC CI_ACES_INDENT
    IF sy-subrc = 0.
      SORT mt_api_map001 BY bapi_struct bapi_field odata_struct.
    ELSE.
      "TODO error handling
    ENDIF.

  endmethod.


  method ODATA_GET_EXTRA_DATA.
  endmethod.


  method PREPARE_BAPIX_PARAMETERS.
    DATA: lr_structdescr TYPE REF TO cl_abap_structdescr,
          lt_components  TYPE cl_abap_structdescr=>component_table,
          lt_componentsx TYPE cl_abap_structdescr=>component_table,
          lr_ref         TYPE REF TO data.

    FIELD-SYMBOLS:
      <lfs_bapi_struct>   TYPE any,
      <lfs_bapix_struct>  TYPE any,
      <lfs_t_bapi_table>  TYPE STANDARD TABLE,
      <lfs_t_bapix_table> TYPE STANDARD TABLE.

    IF iv_bapi_struct IS NOT INITIAL.
      ASSIGN (iv_bapi_struct) TO <lfs_bapi_struct>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
      ASSIGN (iv_bapix_struct) TO <lfs_bapix_struct>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.

      lr_structdescr ?= cl_abap_typedescr=>describe_by_data( <lfs_bapi_struct> ).
      DATA(lv_bapi_stype) = lr_structdescr->get_relative_name( ).
      lt_components = lr_structdescr->get_components( ).

      LOOP AT lt_components ASSIGNING FIELD-SYMBOL(<lfs_comp>).
        ASSIGN COMPONENT <lfs_comp>-name OF STRUCTURE <lfs_bapi_struct> TO FIELD-SYMBOL(<lfs_v_field>).
        IF sy-subrc EQ 0 AND <lfs_v_field> IS ASSIGNED.
          IF <lfs_v_field> IS NOT INITIAL.
            ASSIGN COMPONENT <lfs_comp>-name OF STRUCTURE <lfs_bapix_struct> TO FIELD-SYMBOL(<lfs_v_fieldx>).
            IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
            IF <lfs_v_fieldx> IS ASSIGNED.
              <lfs_v_fieldx> = abap_true.
            ENDIF.
          ENDIF.
        ELSE.
          EXIT.
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF it_bapi_table IS NOT INITIAL.
      ASSIGN (it_bapi_table) TO <lfs_t_bapi_table>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
      ASSIGN (it_bapix_table) TO <lfs_t_bapix_table>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.

      LOOP AT <lfs_t_bapi_table> ASSIGNING FIELD-SYMBOL(<lfs_bapi_line>).
        APPEND INITIAL LINE TO <lfs_t_bapix_table> ASSIGNING FIELD-SYMBOL(<lfs_bapix_line>).
        CLEAR <lfs_bapix_line>.
        lr_structdescr ?= cl_abap_typedescr=>describe_by_data( <lfs_bapix_line> ).
        lv_bapi_stype = lr_structdescr->get_relative_name( ).
        lt_components = lr_structdescr->get_components( ).

        LOOP AT lt_components ASSIGNING <lfs_comp>.
          ASSIGN COMPONENT <lfs_comp>-name OF STRUCTURE <lfs_bapi_line> TO <lfs_v_field>.
          IF sy-subrc EQ 0 AND <lfs_v_field> IS ASSIGNED.
            IF <lfs_v_field> IS NOT INITIAL.
              ASSIGN COMPONENT <lfs_comp>-name OF STRUCTURE <lfs_bapix_line> TO <lfs_v_fieldx>.
              IF sy-subrc EQ 0 AND <lfs_v_fieldx> IS ASSIGNED.
                IF <lfs_comp>-type->absolute_name = ms_abstract_name-bapiupdate. "'\TYPE=BAPIUPDATE'.
                  <lfs_v_fieldx> = abap_true.
                ELSE.
                  <lfs_v_fieldx> = <lfs_v_field>.
                ENDIF.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDLOOP.

      ENDLOOP.
    ENDIF.

  endmethod.


  method PREPARE_BAPI_PARAMETERS.
    me->split_long_text( ).
    TRY.
        me->transfer_odata_to_bapi(
              EXPORTING iv_bapi_struct = ms_bapi_elements-ms_bapisdhd1
                        iv_odata_entity = ms_odata_elements-ms_deep_entity ).
        me->transfer_odata_to_bapi(
              EXPORTING iv_bapi_table = ms_bapi_elements-mt_bapisditm
                        iv_odata_entity = ms_odata_elements-so_itemset ).
        me->transfer_odata_to_bapi(
              EXPORTING iv_bapi_table = ms_bapi_elements-mt_bapiparnr
                        iv_odata_entity = ms_odata_elements-so_hpartnerset ).
        me->transfer_odata_to_bapi(
              EXPORTING iv_bapi_table = ms_bapi_elements-mt_bapischdl
                        iv_odata_entity = ms_odata_elements-so_slineset ).
        ms_deep_entity-so_iprelementset[] = CORRESPONDING #( ms_deep_entity-so_hprelementset[] ).
        me->transfer_odata_to_bapi(
              EXPORTING iv_bapi_table = ms_bapi_elements-mt_bapicond
                        iv_odata_entity = ms_odata_elements-so_iprelementset ).
        me->transfer_odata_to_bapi(
              EXPORTING iv_bapi_table = ms_bapi_elements-mt_bapisdtext
                        iv_odata_entity = ms_odata_elements-so_htextset ).

      CATCH cx_sy_conversion_error INTO DATA(lo_con).
    ENDTRY.

    me->bapi_conversions( ).
*    me->bapi_validations( ).

    me->prepare_bapix_parameters(
          EXPORTING iv_bapi_struct = ms_bapi_elements-ms_bapisdhd1
                    iv_bapix_struct = ms_bapi_elements-ms_bapisdhd1x ).
    me->prepare_bapix_parameters(
          EXPORTING it_bapi_table = ms_bapi_elements-mt_bapisditm
                    it_bapix_table = ms_bapi_elements-mt_bapisditmx ).
    me->prepare_bapix_parameters(
          EXPORTING it_bapi_table = ms_bapi_elements-mt_bapischdl
                    it_bapix_table = ms_bapi_elements-mt_bapischdlx ).
    me->prepare_bapix_parameters(
          EXPORTING it_bapi_table = ms_bapi_elements-mt_bapicond
                    it_bapix_table = ms_bapi_elements-mt_bapicondx ).

    LOOP AT mt_bapisditmx ASSIGNING FIELD-SYMBOL(<lfs_bapisditmx>).
      <lfs_bapisditmx>-vw_uepos = abap_true. "this is what VA01 does at ADNOC
    ENDLOOP.

  endmethod.


  method PREPARE_ODATA_FEEDBACK.

    me->get_mappings( ).
*    me->call_bapi_read( ).
*    me->bapi_get_extra_data( ).
*    me->ms_entity_set_clear( ).

    IF mt_bapisdhd_out IS NOT INITIAL.
      TRY.
          ms_bapisdhd_out = mt_bapisdhd_out[ doc_number = mv_vbeln ].
          TRY.
              me->transfer_bapi_to_odata(
                    EXPORTING iv_bapi_struct = ms_bapi_elements-ms_bapisdhd_out
                              iv_odata_entity = ms_odata_elements-ms_deep_entity ).
              me->transfer_bapi_to_odata(
                    EXPORTING iv_bapi_table = ms_bapi_elements-mt_bapisdit_out
                              iv_odata_entity = ms_odata_elements-so_itemset ).
              me->transfer_bapi_to_odata(
                    EXPORTING iv_bapi_table = ms_bapi_elements-mt_bapisdpart_out
                              iv_odata_entity = ms_odata_elements-so_hpartnerset ).
              me->transfer_bapi_to_odata(
                    EXPORTING iv_bapi_table = ms_bapi_elements-mt_bapisdhedu_out
                              iv_odata_entity = ms_odata_elements-so_slineset ).
              me->transfer_bapi_to_odata(
                    EXPORTING iv_bapi_table = ms_bapi_elements-mt_bapisdcond_out
                              iv_odata_entity = ms_odata_elements-so_iprelementset ).
              me->transfer_bapi_to_odata(
                    EXPORTING iv_bapi_table = ms_bapi_elements-mt_bapitextli_out
                              iv_odata_entity = ms_odata_elements-so_htextset ).
              me->transfer_bapi_to_odata(
                    EXPORTING iv_bapi_table = ms_bapi_elements-mt_bapidlvitem_out
                              iv_odata_entity = ms_odata_elements-so_deliveryset ).

            CATCH cx_sy_conversion_error INTO DATA(lo_con).
          ENDTRY.
        CATCH cx_sy_itab_line_not_found INTO DATA(lo_ex).
      ENDTRY.
*      me->odata_get_extra_data( ).
    ENDIF.

  endmethod.


  METHOD process_single_so.

    TRY.
        DATA(lv_extnumber) = sy-datum && sy-uzeit && cs_deep_entity-salesorder.
        CREATE OBJECT mo_ballog
          EXPORTING
            iv_object    = mc_log_object
            iv_subobject = mc_post_log_subobject
            iv_title     = mc_log_title
            iv_extnumber = lv_extnumber.
*        MESSAGE s001(zsd00) INTO mv_dummy.  "Sales Order Post API call - processing started
        mo_ballog->add_sy_message( ).
        me->append_sy_message_to_bapiret2( CHANGING ct_bapiret2 = mt_bapiret2 ).

        ms_deep_entity = cs_deep_entity.
        me->get_mappings( ).
        me->prepare_bapi_parameters( ).
        me->so_type_rng_prepare( ).
        DATA(lv_vbeln) = me->check_sf_ref_already_exists( ms_deep_entity-salesforcereference ).
        IF lv_vbeln IS INITIAL.
          me->call_bapi_create( ).
          me->prepare_odata_feedback( ).
          IF mv_vbeln IS NOT INITIAL.
*              MESSAGE s002(zsd00) INTO mv_dummy.  "Sales Order Post API call - processing completed
            me->append_sy_message_to_bapiret2(
              CHANGING
                ct_bapiret2 =   mt_bapiret2              " Return table
            ).
            mo_ballog->add_sy_message(
*                is_context =
            ).
          ENDIF.
          else.
           " for given salesforce document - sales order already exists in sap
*          MESSAGE e004(zsd00) WITH ms_deep_entity-salesforcereference lv_vbeln INTO mv_dummy.  "For given SF reference (&1) Sales Order already exists in SAP (&2).
          mo_ballog->add_sy_message( ).
          me->append_sy_message_to_bapiret2( CHANGING ct_bapiret2 = mt_bapiret2 ).
*          MESSAGE e003(zsd00) INTO mv_dummy.  "Sales Order Post API call - processing failed
          me->append_sy_message_to_bapiret2( CHANGING ct_bapiret2 = mt_bapiret2 ).
          mo_ballog->add_sy_message( ).
        ENDIF.
        me->copy_bapiret_to_message( ).
        cs_deep_entity = ms_deep_entity.
        mo_ballog->save( ).
      CATCH zcx_zca_exception INTO DATA(lo_ex).
    ENDTRY.
  ENDMETHOD.


  method RELEASE_ORDER.

     IF mv_vbeln IS NOT INITIAL.
      CALL FUNCTION 'SD_ORDER_CREDIT_RELEASE'
        EXPORTING
          vbeln       = mv_vbeln
          if_synchron = abap_true.
    ENDIF.
  endmethod.


  method SO_TYPE_RNG_PREPARE.

    SELECT sign, opti, low, high FROM tvarvc
      INTO TABLE @DATA(lt_tvarvc)
      WHERE name = @mc_tvarvc_so_type.
    IF sy-subrc = 0.
      LOOP AT lt_tvarvc ASSIGNING FIELD-SYMBOL(<lfs_tvarvc>).
        APPEND INITIAL LINE TO mt_rng_auart ASSIGNING FIELD-SYMBOL(<lfs_rng_auart>).
        CLEAR <lfs_rng_auart>.
        <lfs_rng_auart>-sign    = <lfs_tvarvc>-sign.
        <lfs_rng_auart>-option  = <lfs_tvarvc>-opti.
        <lfs_rng_auart>-low     = <lfs_tvarvc>-low.
        <lfs_rng_auart>-high    = <lfs_tvarvc>-high.
      ENDLOOP.
    ENDIF.
    SELECT sign, opti, low, high FROM tvarvc
      INTO TABLE @lt_tvarvc
      WHERE name = @mc_tvarvc_so_type2.
    IF sy-subrc = 0.
      LOOP AT lt_tvarvc ASSIGNING <lfs_tvarvc>.
        APPEND INITIAL LINE TO mt_rng_auart2 ASSIGNING <lfs_rng_auart>.
        CLEAR <lfs_rng_auart>.
        <lfs_rng_auart>-sign    = <lfs_tvarvc>-sign.
        <lfs_rng_auart>-option  = <lfs_tvarvc>-opti.
        <lfs_rng_auart>-low     = <lfs_tvarvc>-low.
        <lfs_rng_auart>-high    = <lfs_tvarvc>-high.
      ENDLOOP.
    ENDIF.
*    SELECT mandt, vkorg, auart, always2sf, active
*      FROM zsd_t_auartvkorg
*      INTO TABLE @mt_auartvkorg
*      WHERE active = @abap_true.
*    IF sy-subrc <> 0.
*    ELSE.
*      SORT mt_auartvkorg BY vkorg ASCENDING auart ASCENDING.
*    ENDIF.
  endmethod.


  method SPLIT_LONG_TEXT.

     CONSTANTS: lc_separator TYPE char2 VALUE '/n'.

    LOOP AT ms_deep_entity-so_htextset ASSIGNING FIELD-SYMBOL(<lfs_ht>).
      REPLACE ALL OCCURRENCES OF lc_separator IN <lfs_ht>-longtext WITH cl_abap_char_utilities=>newline. "cr_lf.
    ENDLOOP.
    DATA(lt_htext) = ms_deep_entity-so_htextset.
    LOOP AT ms_deep_entity-so_htextset ASSIGNING <lfs_ht>.
      DATA(lv_len) = strlen( <lfs_ht>-longtext ).
      IF  lv_len > 132.
        DATA(lv_i) = ( lv_len DIV 132 ).
        DO lv_i TIMES.
          APPEND INITIAL LINE TO lt_htext ASSIGNING FIELD-SYMBOL(<lfs_htx>).
          CLEAR <lfs_htx>.
          <lfs_htx> = <lfs_ht>.
          CLEAR <lfs_htx>-longtext.
          DATA(lv_pos) = sy-index * 132.
          <lfs_htx>-longtext = <lfs_ht>-longtext+lv_pos.
        ENDDO.
      ENDIF.
    ENDLOOP.
    ms_deep_entity-so_htextset = lt_htext.

*    LOOP AT ms_deep_entity-so_htextset ASSIGNING FIELD-SYMBOL(<lfs_ht>).
*      SPLIT <lfs_ht>-longtext AT lc_separator INTO TABLE DATA(lt_lines).
*      IF sy-subrc = 0.
*        LOOP AT lt_lines ASSIGNING FIELD-SYMBOL(<lfs_lines>).
*        DATA(lv_len) = strlen( <lfs_ht>-longtext ).
*        IF  lv_len > 132.
*          DATA(lv_i) = ( lv_len DIV 132 ).
*          DO lv_i TIMES.
*            APPEND INITIAL LINE TO lt_htext ASSIGNING FIELD-SYMBOL(<lfs_htx>).
*            CLEAR <lfs_htx>.
*            <lfs_htx> = <lfs_ht>.
*            CLEAR <lfs_htx>-longtext.
*            DATA(lv_pos) = sy-index * 132.
*            <lfs_htx>-longtext = <lfs_ht>-longtext+lv_pos.
*          ENDDO.
*        ENDIF.
*        ENDLOOP.
*      ELSE.
*        lv_len = strlen( <lfs_ht>-longtext ).
*        IF  lv_len > 132.
*          lv_i = ( lv_len DIV 132 ).
*          DO lv_i TIMES.
*            APPEND INITIAL LINE TO lt_htext ASSIGNING <lfs_htx>.
*            CLEAR <lfs_htx>.
*            <lfs_htx> = <lfs_ht>.
*            CLEAR <lfs_htx>-longtext.
*            lv_pos = sy-index * 132.
*            <lfs_htx>-longtext = <lfs_ht>-longtext+lv_pos.
*          ENDDO.
*        ENDIF.
*      ENDIF.
*    ENDLOOP.
  endmethod.


  method TRANSFER_BAPI_TO_ODATA.

    DATA: lr_structdescr TYPE REF TO cl_abap_structdescr,
          lt_components  TYPE cl_abap_structdescr=>component_table,
          lr_ref         TYPE REF TO data,
          lv_dec         TYPE p LENGTH 9 DECIMALS 2.
    FIELD-SYMBOLS: "<lfs_comp>   LIKE LINE OF lt_components,
      <lfs_bapi_struct>   TYPE any,
      <lfs_t_bapi_table>  TYPE STANDARD TABLE,
      <lfs_v_bapi_field>  TYPE any,
      <lfs_odata_struct>  TYPE any,
      <lfs_t_odata_table> TYPE STANDARD TABLE,
      <lfs_v_odata_field> TYPE any.

    IF iv_bapi_struct IS NOT INITIAL.
      ASSIGN (iv_bapi_struct) TO <lfs_bapi_struct>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
      ASSIGN (iv_odata_entity) TO <lfs_odata_struct>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.

      lr_structdescr ?= cl_abap_typedescr=>describe_by_data( <lfs_odata_struct> ).
      DATA(lv_odata_stype) = lr_structdescr->get_relative_name( ).
      lr_structdescr ?= cl_abap_typedescr=>describe_by_data( <lfs_bapi_struct> ).
      DATA(lv_bapi_stype) = lr_structdescr->get_relative_name( ).
      lt_components = lr_structdescr->get_components( ).

      LOOP AT lt_components ASSIGNING FIELD-SYMBOL(<lfs_comp>).
        READ TABLE mt_api_map001 ASSIGNING FIELD-SYMBOL(<lfs_map001>) WITH KEY bapi_struct = lv_bapi_stype bapi_field = <lfs_comp>-name odata_struct = lv_odata_stype BINARY SEARCH.
        IF sy-subrc EQ 0 AND <lfs_map001>-odata_field IS NOT INITIAL.
          ASSIGN COMPONENT <lfs_comp>-name OF STRUCTURE <lfs_bapi_struct> TO <lfs_v_bapi_field>.
          IF sy-subrc = 0. ELSE. CONTINUE. ENDIF. "TODO - handling.
          ASSIGN COMPONENT <lfs_map001>-odata_field OF STRUCTURE <lfs_odata_struct> TO <lfs_v_odata_field>.
          IF sy-subrc = 0. ELSE. CONTINUE. ENDIF. "TODO - handling.
          IF <lfs_v_bapi_field> IS ASSIGNED AND <lfs_v_odata_field> IS ASSIGNED.
            TRY.
                DATA(lr_type) = <lfs_comp>-type.
                IF lr_type->type_kind = ms_abap_typekind-p AND lr_type->decimals > 3.
                  CALL FUNCTION 'ROUND'
                    EXPORTING
                      decimals      = '2'
                      input         = <lfs_v_bapi_field>
                      sign          = abap_true
                    IMPORTING
                      output        = lv_dec
                    EXCEPTIONS
                      input_invalid = 1
                      overflow      = 2
                      type_invalid  = 3
                      OTHERS        = 4.
                  IF sy-subrc <> 0.
* Implement suitable error handling here
                  ELSE.
                    <lfs_v_odata_field> = lv_dec.
                  ENDIF.
                ELSE.
                  <lfs_v_odata_field> = <lfs_v_bapi_field>.
                ENDIF.
              CATCH cx_sy_conversion_error INTO DATA(lo_con).
            ENDTRY.
          ENDIF.
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF iv_bapi_table IS NOT INITIAL.
      ASSIGN (iv_bapi_table) TO <lfs_t_bapi_table>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
      ASSIGN (iv_odata_entity) TO <lfs_t_odata_table>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
*      CREATE DATA lr_ref LIKE STANDARD TABLE OF <lfs_bapi_struct>.
*      ASSIGN lr_ref->* TO <lfs_t_bapi_table>.

      LOOP AT <lfs_t_bapi_table> ASSIGNING <lfs_bapi_struct>.
        APPEND INITIAL LINE TO <lfs_t_odata_table> ASSIGNING <lfs_odata_struct>.
        CLEAR <lfs_odata_struct>.
        lr_structdescr ?= cl_abap_typedescr=>describe_by_data( <lfs_odata_struct> ).
        lv_odata_stype = lr_structdescr->get_relative_name( ).
        lr_structdescr ?= cl_abap_typedescr=>describe_by_data( <lfs_bapi_struct> ).
        lv_bapi_stype = lr_structdescr->get_relative_name( ).
        lt_components = lr_structdescr->get_components( ).

        LOOP AT lt_components ASSIGNING <lfs_comp>.
          READ TABLE mt_api_map001 ASSIGNING <lfs_map001> WITH KEY bapi_struct = lv_bapi_stype bapi_field = <lfs_comp>-name odata_struct = lv_odata_stype BINARY SEARCH.
          IF sy-subrc EQ 0 AND <lfs_map001>-odata_field IS NOT INITIAL.
            ASSIGN COMPONENT <lfs_comp>-name OF STRUCTURE <lfs_bapi_struct> TO <lfs_v_bapi_field>.
            IF sy-subrc = 0. ELSE. CONTINUE. ENDIF. "TODO - handling.
            ASSIGN COMPONENT <lfs_map001>-odata_field OF STRUCTURE <lfs_odata_struct> TO <lfs_v_odata_field>.
            IF sy-subrc = 0. ELSE. CONTINUE. ENDIF. "TODO - handling.
            IF <lfs_v_bapi_field> IS ASSIGNED AND <lfs_v_odata_field> IS ASSIGNED.
              TRY.
                  lr_type = <lfs_comp>-type.
                  IF lr_type->type_kind = ms_abap_typekind-p AND lr_type->decimals > 3.
                    CALL FUNCTION 'ROUND'
                      EXPORTING
                        decimals      = '2'
                        input         = <lfs_v_bapi_field>
                        sign          = abap_true
                      IMPORTING
                        output        = lv_dec
                      EXCEPTIONS
                        input_invalid = 1
                        overflow      = 2
                        type_invalid  = 3
                        OTHERS        = 4.
                    IF sy-subrc <> 0.
* Implement suitable error handling here
                    ELSE.
                      <lfs_v_odata_field> = lv_dec.
                    ENDIF.
                  ELSE.
                    <lfs_v_odata_field> = <lfs_v_bapi_field>.
                  ENDIF.
                CATCH cx_sy_conversion_error INTO lo_con.
              ENDTRY.
            ENDIF.
          ENDIF.
        ENDLOOP.

      ENDLOOP.
    ENDIF.
  endmethod.


  method TRANSFER_ODATA_TO_BAPI.
    DATA: lr_structdescr    TYPE REF TO cl_abap_structdescr,
          lt_components     TYPE abap_component_view_tab, "cl_abap_structdescr=>component_table,
          lr_ref            TYPE REF TO data,
          lt_included_views TYPE abap_component_view_tab.
    FIELD-SYMBOLS: "<lfs_comp>   LIKE LINE OF lt_components,
      <lfs_bapi_struct>   TYPE any,
      <lfs_t_bapi_table>  TYPE STANDARD TABLE,
      <lfs_v_bapi_field>  TYPE any,
      <lfs_odata_struct>  TYPE any,
      <lfs_t_odata_table> TYPE STANDARD TABLE,
      <lfs_v_odata_field> TYPE any.

    IF iv_bapi_struct IS NOT INITIAL.
      ASSIGN (iv_bapi_struct) TO <lfs_bapi_struct>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
      ASSIGN (iv_odata_entity) TO <lfs_odata_struct>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.

      lr_structdescr ?= cl_abap_typedescr=>describe_by_data( <lfs_odata_struct> ).
      DATA(lv_odata_stype) = lr_structdescr->get_relative_name( ).
      lr_structdescr ?= cl_abap_typedescr=>describe_by_data( <lfs_bapi_struct> ).
      DATA(lv_bapi_stype) = lr_structdescr->get_relative_name( ).
*      lt_components = lr_structdescr->get_components( ).
      lt_components = lr_structdescr->get_included_view( ).

      LOOP AT lt_components ASSIGNING FIELD-SYMBOL(<lfs_comp>).
        READ TABLE mt_api_map001 ASSIGNING FIELD-SYMBOL(<lfs_map001>) WITH KEY bapi_struct = lv_bapi_stype bapi_field = <lfs_comp>-name odata_struct = lv_odata_stype BINARY SEARCH.
        IF sy-subrc EQ 0 AND <lfs_map001>-odata_field IS NOT INITIAL.
          ASSIGN COMPONENT <lfs_comp>-name OF STRUCTURE <lfs_bapi_struct> TO <lfs_v_bapi_field>.
          IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
          ASSIGN COMPONENT <lfs_map001>-odata_field OF STRUCTURE <lfs_odata_struct> TO <lfs_v_odata_field>.
          IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
          IF <lfs_v_bapi_field> IS ASSIGNED AND <lfs_v_odata_field> IS ASSIGNED.
            TRY.
                <lfs_v_bapi_field> = <lfs_v_odata_field>.
              CATCH cx_sy_conversion_error INTO DATA(lo_con).
            ENDTRY.
          ENDIF.
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF iv_bapi_table IS NOT INITIAL.
      ASSIGN (iv_bapi_table) TO <lfs_t_bapi_table>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
      ASSIGN (iv_odata_entity) TO <lfs_t_odata_table>.
      IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
*      CREATE DATA lr_ref LIKE STANDARD TABLE OF <lfs_bapi_struct>.
*      ASSIGN lr_ref->* TO <lfs_t_bapi_table>.

      LOOP AT <lfs_t_odata_table> ASSIGNING <lfs_odata_struct>.
        APPEND INITIAL LINE TO <lfs_t_bapi_table> ASSIGNING <lfs_bapi_struct>.
        CLEAR <lfs_bapi_struct>.
        lr_structdescr ?= cl_abap_typedescr=>describe_by_data( <lfs_odata_struct> ).
        lv_odata_stype = lr_structdescr->get_relative_name( ).
        lr_structdescr ?= cl_abap_typedescr=>describe_by_data( <lfs_bapi_struct> ).
        lv_bapi_stype = lr_structdescr->get_relative_name( ).
*        lt_components = lr_structdescr->get_components( ).
        lt_components = lr_structdescr->get_included_view( ).

        LOOP AT lt_components ASSIGNING <lfs_comp>.
          READ TABLE mt_api_map001 ASSIGNING <lfs_map001> WITH KEY bapi_struct = lv_bapi_stype bapi_field = <lfs_comp>-name odata_struct = lv_odata_stype BINARY SEARCH.
          IF sy-subrc EQ 0 AND <lfs_map001>-odata_field IS NOT INITIAL.
            ASSIGN COMPONENT <lfs_comp>-name OF STRUCTURE <lfs_bapi_struct> TO <lfs_v_bapi_field>.
            IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
            ASSIGN COMPONENT <lfs_map001>-odata_field OF STRUCTURE <lfs_odata_struct> TO <lfs_v_odata_field>.
            IF sy-subrc = 0. ELSE. ENDIF. "TODO - handling.
            IF <lfs_v_bapi_field> IS ASSIGNED AND <lfs_v_odata_field> IS ASSIGNED.
              TRY.
                  <lfs_v_bapi_field> = <lfs_v_odata_field>.
                CATCH cx_sy_conversion_error INTO lo_con.
              ENDTRY.
            ENDIF.
          ENDIF.
        ENDLOOP.

      ENDLOOP.
    ENDIF.
  endmethod.


  method UPDATE_JEST_STATUS.

    DATA: lv_current_status TYPE j_estat,
          lv_target_status  TYPE j_estat,
          lt_ssi            TYPE TABLE OF istatus_range,
          lt_sse            TYPE TABLE OF istatus_range,
          lt_usi            TYPE TABLE OF istatus_range,
          lt_use            TYPE TABLE OF istatus_range.
*          lv_inact          TYPE j_inact,
*          lv_safety_out     TYPE i.

    SELECT objnr, vbeln, posnr FROM onrvb
      INTO TABLE @DATA(lt_onrvb)
      WHERE vbeln = @mv_vbeln.
    IF sy-subrc <> 0.
      "Do nothing
    ELSE.
      SORT lt_onrvb BY objnr DESCENDING.

      LOOP AT lt_onrvb ASSIGNING FIELD-SYMBOL(<lfs_onrvb>).
        CALL FUNCTION 'I_STATUS_SELECT'
          EXPORTING
            objnr               = <lfs_onrvb>-objnr
            sent_user_status    = ms_user_status-rel
          IMPORTING
            current_user_status = lv_current_status
            next_user_status    = lv_target_status
          TABLES
            syst_status_incl    = lt_ssi
            syst_status_excl    = lt_sse
            user_status_incl    = lt_usi
            user_status_excl    = lt_use.

        CALL FUNCTION 'I_CHANGE_STATUS'
          EXPORTING
            objnr          = <lfs_onrvb>-objnr
            estat_inactive = lv_current_status "mc_estat_init
            estat_active   = lv_target_status "mc_estat_rel
*           STSMA          =
          EXCEPTIONS
            cannot_update  = 1
            OTHERS         = 2.
        IF sy-subrc <> 0.
* Implement suitable error handling here
        ELSE.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
            EXPORTING
              wait = abap_true.
        ENDIF.
      ENDLOOP.
       ENDIF.
  endmethod.


  method WAIT_FOR_LOMOSOFT_STAT_UPDATE.

    CONSTANTS: lc_program TYPE program VALUE 'ZSD_SF_INT_LOMOSOFT_STAT_UPD',
               lc_field   TYPE rollname VALUE 'BKK_TS_WAIT_SEC'.

*    CALL METHOD zcl_utility_class=>fetch_tvarv_field
*      EXPORTING
*        iv_objname = lc_program
*        iv_field   = lc_field
*      IMPORTING
*        et_final   = DATA(lt_tvarv).
*
*    LOOP AT lt_tvarv ASSIGNING FIELD-SYMBOL(<lfs_tvarv>).
*      DATA(lv_wait) = <lfs_tvarv>-low.
*    ENDLOOP.

*    IF lv_wait IS INITIAL.
*      lv_wait = 10.
*    ENDIF.
*
*    DO lv_wait TIMES.
*      me->get_lomosoft_status( ).
*      IF ms_deep_entity-statuslomosoft <> ms_user_status-rel.
*        EXIT.
*      ELSE.
*        WAIT UP TO 1 SECONDS.
*      ENDIF.
*    ENDDO.

  endmethod.
ENDCLASS.
