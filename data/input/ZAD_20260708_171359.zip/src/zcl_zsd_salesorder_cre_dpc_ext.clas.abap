class ZCL_ZSD_SALESORDER_CRE_DPC_EXT definition
  public
  inheriting from ZCL_ZSD_SALESORDER_CRE_DPC
  create public .

public section.

  methods /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_DEEP_ENTITY
    redefinition .
protected section.
private section.

  data:
    BEGIN OF ms_entity_types,
          so_header  TYPE string VALUE 'SO_HEADER',
          so_request TYPE string VALUE 'SO_REQUEST',
        END OF ms_entity_types .
  data MS_DEEP_ENTITY type ZSD_S_SO_HEADER_EXP .
ENDCLASS.



CLASS ZCL_ZSD_SALESORDER_CRE_DPC_EXT IMPLEMENTATION.


  method /IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_DEEP_ENTITY.
**TRY.
*CALL METHOD SUPER->/IWBEP/IF_MGW_APPL_SRV_RUNTIME~CREATE_DEEP_ENTITY
*  EXPORTING
**    iv_entity_name          =
**    iv_entity_set_name      =
**    iv_source_name          =
*    IO_DATA_PROVIDER        =
**    it_key_tab              =
**    it_navigation_path      =
*    IO_EXPAND               =
**    io_tech_request_context =
**  IMPORTING
**    er_deep_entity          =
*    .
**  CATCH /iwbep/cx_mgw_busi_exception.
**  CATCH /iwbep/cx_mgw_tech_exception.
**ENDTRY.

    DATA: ls_deep_entity_h TYPE zsd_s_so_header_exp,
          ls_deep_entity_r TYPE zsd_s_so_request_exp2.

    data(lo_instance) = ZCL_ZSD_SALESORDER=>GET_INSTANCE( ).

    CASE iv_entity_name.
      WHEN ms_entity_types-so_header. "'SO_Header'.
        io_data_provider->read_entry_data( IMPORTING es_data = ls_deep_entity_h ).
        lo_instance->process_single_so( CHANGING cs_deep_entity = ls_deep_entity_h ).
      WHEN ms_entity_types-so_request. "'SO_Request'.
        io_data_provider->read_entry_data( IMPORTING es_data = ls_deep_entity_r ).
*        lo_instance->process_multi_so( CHANGING cs_deep_entity = ls_deep_entity_r ).
    ENDCASE.




  endmethod.
ENDCLASS.
