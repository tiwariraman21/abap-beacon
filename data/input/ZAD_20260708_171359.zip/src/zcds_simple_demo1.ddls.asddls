@AbapCatalog.sqlViewName: 'ZCDS_SIMPLE_SQL'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'cds Simple'
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
    }
define view ZCDS_SIMPLE_Demo1 
//with parameters p_vbtyp : vbtyp 
//,P_VKORG : vkorg
as select from vbak
{
     key vbeln as SaleDocNo,
  vbtyp,
  vkorg,
  vtweg,
  spart,
  kunnr,
 // netwr,
  
   case vbtyp
        when 'A' then 'Inquiry'
        when 'B' then 'Quotation'
        when 'C' then //'Order' 
            case netwr
                 when 0 then 'Order - Not Paid'
                else 'Order - Paid'
            end    
        else 'Others'
    end as DocCatText,    
  
    $session.client as ClientNum,
    $session.system_date as SystemDate,
    $session.system_language as SystemLanguage,
    $session.user as UserName,
    $session.user_date as UserDate,
    $session.user_timezone as UserTimeZone  
}
//where vbtyp = 'C'
//where vbtyp = $parameters.p_vbtyp
//and vkorg = $parameters.P_VKORG
